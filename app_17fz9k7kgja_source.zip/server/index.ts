import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { initDatabase } from './db/index.js';
import authRouter from './routes/auth.js';
import booksRouter from './routes/books.js';
import adminRouter from './routes/admin.js';
import announcementRouter from './routes/announcement.js';
import redemptionRouter from './routes/redemption.js';
import { logger } from '@lark-apaas/client-toolkit-lite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 3001;

// 中间件
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// 初始化数据库
initDatabase();

// API 路由
app.use('/api/auth', authRouter);
app.use('/api/books', booksRouter);
app.use('/api/admin', adminRouter);
app.use('/api/announcement', announcementRouter);
app.use('/api/redemption', redemptionRouter);

// 健康检查
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: Date.now() });
});

// 静态文件：前端 dist
const distPath = path.resolve(__dirname, '../../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));

  // SPA 路由回退
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

// 启动
app.listen(PORT, () => {
  logger.info(`[server] 后端服务启动，端口 ${PORT}`);
  logger.info(`[server] API 前缀: /api`);
});

export default app;
