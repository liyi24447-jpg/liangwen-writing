import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import { logger } from '@lark-apaas/client-toolkit-lite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 数据库文件路径（放在项目 data 目录下，持久化）
const DB_DIR = path.resolve(__dirname, '../../data');
const DB_PATH = path.join(DB_DIR, 'app.db');

if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

let db: Database.Database;

export function getDb(): Database.Database {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
  }
  return db;
}

// ========== 初始化表结构 ==========
export function initDatabase(): void {
  const database = getDb();

  database.exec(`
    -- 用户表
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      is_admin INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      -- 会员等级：none / plus / ultra
      membership_level TEXT NOT NULL DEFAULT 'none',
      -- 会员到期时间戳（毫秒），0 表示永久或非会员
      membership_expire_at INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    -- 功能权限表（按用户配置，每个用户一条记录，字段对应各功能开关）
    CREATE TABLE IF NOT EXISTS user_permissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      -- 各功能模块：1=启用, 0=禁用
      can_write_short INTEGER NOT NULL DEFAULT 1,    -- 短篇创作
      can_disassemble INTEGER NOT NULL DEFAULT 1,   -- 拆书分析
      can_hot_rank INTEGER NOT NULL DEFAULT 1,      -- 网文扫榜
      can_optimize INTEGER NOT NULL DEFAULT 1,      -- 去AI味
      can_workbench INTEGER NOT NULL DEFAULT 1,     -- 书案工作台
      can_upload_continue INTEGER NOT NULL DEFAULT 1, -- 上传续写
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    -- 作品表
    CREATE TABLE IF NOT EXISTS books (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL DEFAULT '未命名作品',
      genre TEXT NOT NULL DEFAULT '玄幻',
      category_group TEXT NOT NULL DEFAULT 'male',
      setting TEXT NOT NULL DEFAULT '',
      writing_style TEXT NOT NULL DEFAULT '朴实真挚',
      narrative_perspective TEXT NOT NULL DEFAULT 'third',
      style_description TEXT NOT NULL DEFAULT '',
      style_guide TEXT,
      synopsis TEXT,
      blurb TEXT,
      blurb_word_count TEXT,
      blurb_focus TEXT,
      outline TEXT,
      script_content TEXT,
      word_count INTEGER NOT NULL DEFAULT 0,
      chapter_count INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_books_user_id ON books(user_id);

    -- 书名候选表
    CREATE TABLE IF NOT EXISTS book_title_candidates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id TEXT NOT NULL,
      title TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    -- 人物小传表
    CREATE TABLE IF NOT EXISTS characters (
      id TEXT PRIMARY KEY,
      book_id TEXT NOT NULL,
      name TEXT NOT NULL,
      identity TEXT,
      gender TEXT,
      personality TEXT,
      background TEXT,
      relationship TEXT,
      character_arc TEXT,
      key_traits TEXT,
      extra_fields TEXT, -- JSON 字符串
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_characters_book_id ON characters(book_id);

    -- 卷表
    CREATE TABLE IF NOT EXISTS volumes (
      id TEXT PRIMARY KEY,
      book_id TEXT NOT NULL,
      title TEXT NOT NULL,
      summary TEXT,
      chapter_count INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_volumes_book_id ON volumes(book_id);

    -- 章节表
    CREATE TABLE IF NOT EXISTS chapters (
      id TEXT PRIMARY KEY,
      book_id TEXT NOT NULL,
      volume_id TEXT,
      title TEXT NOT NULL,
      summary TEXT,
      word_count INTEGER NOT NULL DEFAULT 0,
      content TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
      FOREIGN KEY (volume_id) REFERENCES volumes(id) ON DELETE SET NULL
    );

    CREATE INDEX IF NOT EXISTS idx_chapters_book_id ON chapters(book_id);
    CREATE INDEX IF NOT EXISTS idx_chapters_volume_id ON chapters(volume_id);

    -- 公告表（仅一条记录，保存最新公告）
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL DEFAULT '',
      content TEXT NOT NULL DEFAULT '',
      is_enabled INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL
    );

    -- 兑换码表
    CREATE TABLE IF NOT EXISTS redemption_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      -- 会员等级：plus / ultra
      membership_level TEXT NOT NULL DEFAULT 'plus',
      -- 兑换后延长天数
      days INTEGER NOT NULL DEFAULT 30,
      -- 是否启用：1=启用, 0=停用
      is_active INTEGER NOT NULL DEFAULT 1,
      -- 是否已被兑换：1=已兑换, 0=未兑换
      is_used INTEGER NOT NULL DEFAULT 0,
      -- 兑换人 user_id
      used_by INTEGER,
      -- 兑换时间
      used_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_redemption_codes_code ON redemption_codes(code);

    -- 每日字数统计表（用于 plus 会员每日 10 万字限制）
    CREATE TABLE IF NOT EXISTS daily_word_stats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      -- 日期字符串：YYYY-MM-DD
      date_str TEXT NOT NULL,
      -- 当日累计生成字数
      word_count INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL,
      UNIQUE(user_id, date_str),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_daily_word_stats_user_date ON daily_word_stats(user_id, date_str);
  `);

  // 检查并创建默认管理员（首次启动）
  const adminRow = database.prepare('SELECT id FROM users WHERE is_admin = 1').get();
  if (!adminRow) {
    const now = Date.now();
    const hash = bcrypt.hashSync('admin123456', 10);
    const info = database
      .prepare(
        'INSERT INTO users (account, password_hash, is_admin, is_active, created_at, updated_at) VALUES (?, ?, 1, 1, ?, ?)'
      )
      .run('admin', hash, now, now);

    // 管理员权限全开
    database
      .prepare(
        `INSERT INTO user_permissions 
        (user_id, can_write_short, can_disassemble, can_hot_rank, can_optimize, can_workbench, can_upload_continue, created_at, updated_at)
        VALUES (?, 1, 1, 1, 1, 1, 1, ?, ?)`
      )
      .run(info.lastInsertRowid, now, now);

    logger.info('[db] 已创建默认管理员账号: admin / admin123456（请登录后尽快修改密码）');
  }

  logger.info('[db] 数据库初始化完成');
}

export default getDb;
