import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import type { Request, Response, NextFunction } from 'express';
import { getDb } from '../db/index.js';

export const JWT_SECRET = process.env.JWT_SECRET || 'liangwen-writing-jwt-secret-2024';
export const JWT_EXPIRES_IN = '30d';

export interface AuthPayload {
  userId: number;
  account: string;
  isAdmin: boolean;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthPayload;
    }
  }
}

/**
 * 生成 JWT token
 */
export function signToken(payload: AuthPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

/**
 * 验证 JWT token
 */
export function verifyToken(token: string): AuthPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthPayload;
    return decoded;
  } catch {
    return null;
  }
}

/**
 * 密码哈希
 */
export function hashPassword(password: string): string {
  return bcrypt.hashSync(password, 10);
}

/**
 * 密码校验
 */
export function verifyPassword(password: string, hash: string): boolean {
  return bcrypt.compareSync(password, hash);
}

/**
 * 认证中间件：需要登录
 */
export function authRequired(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, message: '未登录或登录已过期' });
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ success: false, message: '未登录或登录已过期' });
    return;
  }

  // 校验用户是否存在且激活
  const db = getDb();
  const user = db.prepare('SELECT id, account, is_admin, is_active FROM users WHERE id = ?').get(payload.userId) as
    | { id: number; account: string; is_admin: number; is_active: number }
    | undefined;

  if (!user || !user.is_active) {
    res.status(401).json({ success: false, message: '账号不存在或已被禁用' });
    return;
  }

  req.user = {
    userId: user.id,
    account: user.account,
    isAdmin: user.is_admin === 1,
  };
  next();
}

/**
 * 管理员中间件：需要管理员权限
 */
export function adminRequired(req: Request, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ success: false, message: '未登录' });
    return;
  }
  if (!req.user.isAdmin) {
    res.status(403).json({ success: false, message: '无管理员权限' });
    return;
  }
  next();
}
