import { Router } from 'express';
import { getDb } from '../db/index.js';
import { authRequired } from '../middleware/auth.js';

const router = Router();

// ========== 获取当前启用的公告（登录用户） ==========
router.get('/current', authRequired, (_req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT id, title, content, is_enabled, updated_at FROM announcements WHERE is_enabled = 1 ORDER BY id DESC LIMIT 1')
    .get() as Record<string, unknown> | undefined;

  if (!row) {
    res.json({ success: true, data: null });
    return;
  }

  res.json({
    success: true,
    data: {
      id: row.id,
      title: row.title,
      content: row.content,
      isEnabled: row.is_enabled === 1,
      updatedAt: row.updated_at,
    },
  });
});

export default router;
