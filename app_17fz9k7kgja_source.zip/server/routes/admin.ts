import { Router } from 'express';
import { getDb } from '../db/index.js';
import { authRequired, adminRequired, hashPassword } from '../middleware/auth.js';

const router = Router();

// ========== 管理员：获取所有用户列表 ==========
router.get('/users', authRequired, adminRequired, (req, res) => {
  const db = getDb();
  const users = db
    .prepare(
      `SELECT u.id, u.account, u.is_admin, u.is_active, u.created_at, u.updated_at,
        u.membership_level, u.membership_expire_at,
        p.can_write_short, p.can_disassemble, p.can_hot_rank, p.can_optimize, p.can_workbench, p.can_upload_continue
       FROM users u
       LEFT JOIN user_permissions p ON u.id = p.user_id
       ORDER BY u.created_at DESC`
    )
    .all() as Array<Record<string, unknown>>;

  const now = Date.now();
  const result = users.map((u) => {
    const rawLevel = (u.membership_level as string) || 'none';
    const rawExpire = (u.membership_expire_at as number) || 0;
    const level = rawExpire > 0 && rawExpire < now ? 'none' : rawLevel;
    return {
      id: u.id,
      account: u.account,
      isAdmin: u.is_admin === 1,
      isActive: u.is_active === 1,
      createdAt: u.created_at,
      updatedAt: u.updated_at,
      membershipLevel: level,
      membershipExpireAt: level === 'none' ? 0 : rawExpire,
      permissions: {
        canWriteShort: u.can_write_short === 1,
        canDisassemble: u.can_disassemble === 1,
        canHotRank: u.can_hot_rank === 1,
        canOptimize: u.can_optimize === 1,
        canWorkbench: u.can_workbench === 1,
        canUploadContinue: u.can_upload_continue === 1,
      },
    };
  });

  res.json({ success: true, data: result });
});

// ========== 管理员：禁用/启用用户 ==========
router.post('/users/:id/toggle-status', authRequired, adminRequired, (req, res) => {
  const userId = Number(req.params.id);
  if (!userId) {
    res.status(400).json({ success: false, message: '用户 ID 无效' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id, is_active, is_admin FROM users WHERE id = ?').get(userId) as
    | { id: number; is_active: number; is_admin: number }
    | undefined;

  if (!user) {
    res.status(404).json({ success: false, message: '用户不存在' });
    return;
  }

  if (user.is_admin === 1) {
    res.status(400).json({ success: false, message: '不能禁用管理员账号' });
    return;
  }

  const newStatus = user.is_active === 1 ? 0 : 1;
  db.prepare('UPDATE users SET is_active = ?, updated_at = ? WHERE id = ?').run(
    newStatus,
    Date.now(),
    userId
  );

  res.json({
    success: true,
    message: newStatus === 1 ? '账号已启用' : '账号已禁用',
    data: { isActive: newStatus === 1 },
  });
});

// ========== 管理员：重置用户密码 ==========
router.post('/users/:id/reset-password', authRequired, adminRequired, (req, res) => {
  const userId = Number(req.params.id);
  const { newPassword } = req.body as { newPassword?: string };

  if (!userId) {
    res.status(400).json({ success: false, message: '用户 ID 无效' });
    return;
  }
  if (!newPassword || newPassword.length < 6) {
    res.status(400).json({ success: false, message: '新密码长度至少 6 位' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(userId);
  if (!user) {
    res.status(404).json({ success: false, message: '用户不存在' });
    return;
  }

  const hash = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
    hash,
    Date.now(),
    userId
  );

  res.json({ success: true, message: '密码重置成功' });
});

// ========== 管理员：更新用户权限 ==========
router.post('/users/:id/permissions', authRequired, adminRequired, (req, res) => {
  const userId = Number(req.params.id);
  const perms = req.body as Record<string, boolean>;

  if (!userId) {
    res.status(400).json({ success: false, message: '用户 ID 无效' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(userId);
  if (!user) {
    res.status(404).json({ success: false, message: '用户不存在' });
    return;
  }

  const now = Date.now();
  const toInt = (v: boolean | undefined, def = 1) => (v === undefined ? def : v ? 1 : 0);

  // 先检查权限记录是否存在
  const existing = db.prepare('SELECT id FROM user_permissions WHERE user_id = ?').get(userId);

  if (existing) {
    db.prepare(
      `UPDATE user_permissions SET
        can_write_short = ?, can_disassemble = ?, can_hot_rank = ?,
        can_optimize = ?, can_workbench = ?, can_upload_continue = ?,
        updated_at = ?
       WHERE user_id = ?`
    ).run(
      toInt(perms.canWriteShort),
      toInt(perms.canDisassemble),
      toInt(perms.canHotRank),
      toInt(perms.canOptimize),
      toInt(perms.canWorkbench),
      toInt(perms.canUploadContinue),
      now,
      userId
    );
  } else {
    db.prepare(
      `INSERT INTO user_permissions
        (user_id, can_write_short, can_disassemble, can_hot_rank, can_optimize, can_workbench, can_upload_continue, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      userId,
      toInt(perms.canWriteShort),
      toInt(perms.canDisassemble),
      toInt(perms.canHotRank),
      toInt(perms.canOptimize),
      toInt(perms.canWorkbench),
      toInt(perms.canUploadContinue),
      now,
      now
    );
  }

  res.json({ success: true, message: '权限更新成功' });
});

// ========== 管理员：删除用户 ==========
router.delete('/users/:id', authRequired, adminRequired, (req, res) => {
  const userId = Number(req.params.id);
  if (!userId) {
    res.status(400).json({ success: false, message: '用户 ID 无效' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id, is_admin FROM users WHERE id = ?').get(userId) as
    | { id: number; is_admin: number }
    | undefined;

  if (!user) {
    res.status(404).json({ success: false, message: '用户不存在' });
    return;
  }

  if (user.is_admin === 1) {
    res.status(400).json({ success: false, message: '不能删除管理员账号' });
    return;
  }

  // 检查是不是自己
  if (req.user && req.user.userId === userId) {
    res.status(400).json({ success: false, message: '不能删除自己的账号' });
    return;
  }

  db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  res.json({ success: true, message: '用户已删除' });
});

// ========== 管理员：设置用户会员 ==========
router.post('/users/:id/membership', authRequired, adminRequired, (req, res) => {
  const userId = Number(req.params.id);
  const { level, days } = req.body as { level?: string; days?: number };

  if (!userId) {
    res.status(400).json({ success: false, message: '用户 ID 无效' });
    return;
  }
  if (!level || !['none', 'plus', 'ultra'].includes(level)) {
    res.status(400).json({ success: false, message: '会员等级无效' });
    return;
  }

  const db = getDb();
  const user = db.prepare('SELECT id, is_admin FROM users WHERE id = ?').get(userId) as
    | { id: number; is_admin: number }
    | undefined;

  if (!user) {
    res.status(404).json({ success: false, message: '用户不存在' });
    return;
  }

  const now = Date.now();
  let expireAt = 0;

  if (level === 'none') {
    expireAt = 0;
  } else {
    const dayCount = typeof days === 'number' && days > 0 ? days : 30;
    expireAt = now + dayCount * 24 * 60 * 60 * 1000;
  }

  db.prepare('UPDATE users SET membership_level = ?, membership_expire_at = ?, updated_at = ? WHERE id = ?').run(
    level,
    expireAt,
    now,
    userId
  );

  res.json({
    success: true,
    message: level === 'none' ? '已取消会员' : `已设置为 ${level === 'ultra' ? 'Ultra' : 'Plus'} 会员`,
    data: { membershipLevel: level, membershipExpireAt: expireAt },
  });
});

// ========== 管理员：延长/修改会员到期时间 ==========
router.post('/users/:id/membership/extend', authRequired, adminRequired, (req, res) => {
  const userId = Number(req.params.id);
  const { days } = req.body as { days?: number };

  if (!userId) {
    res.status(400).json({ success: false, message: '用户 ID 无效' });
    return;
  }
  if (typeof days !== 'number') {
    res.status(400).json({ success: false, message: '天数无效' });
    return;
  }

  const db = getDb();
  const user = db
    .prepare('SELECT id, membership_level, membership_expire_at FROM users WHERE id = ?')
    .get(userId) as
    | { id: number; membership_level: string; membership_expire_at: number }
    | undefined;

  if (!user) {
    res.status(404).json({ success: false, message: '用户不存在' });
    return;
  }

  const now = Date.now();
  const extendMs = days * 24 * 60 * 60 * 1000;
  const baseTime = user.membership_expire_at > now ? user.membership_expire_at : now;
  const newExpireAt = baseTime + extendMs;

  const newLevel = user.membership_level === 'none' ? 'plus' : user.membership_level;

  db.prepare('UPDATE users SET membership_level = ?, membership_expire_at = ?, updated_at = ? WHERE id = ?').run(
    newLevel,
    newExpireAt,
    now,
    userId
  );

  res.json({
    success: true,
    message: `已延长 ${days} 天`,
    data: { membershipLevel: newLevel, membershipExpireAt: newExpireAt },
  });
});

// ========== 管理员：获取公告 ==========
router.get('/announcement', authRequired, adminRequired, (_req, res) => {
  const db = getDb();
  const row = db
    .prepare('SELECT id, title, content, is_enabled, updated_at FROM announcements ORDER BY id DESC LIMIT 1')
    .get() as Record<string, unknown> | undefined;

  res.json({
    success: true,
    data: row
      ? {
          id: row.id,
          title: row.title,
          content: row.content,
          isEnabled: row.is_enabled === 1,
          updatedAt: row.updated_at,
        }
      : null,
  });
});

// ========== 管理员：保存公告 ==========
router.post('/announcement', authRequired, adminRequired, (req, res) => {
  const { title, content, isEnabled } = req.body as {
    title?: string;
    content?: string;
    isEnabled?: boolean;
  };

  const db = getDb();
  const now = Date.now();
  const titleVal = title || '';
  const contentVal = content || '';
  const enabled = isEnabled ? 1 : 0;

  const existing = db.prepare('SELECT id FROM announcements ORDER BY id DESC LIMIT 1').get() as
    | { id: number }
    | undefined;

  if (existing) {
    db.prepare('UPDATE announcements SET title = ?, content = ?, is_enabled = ?, updated_at = ? WHERE id = ?').run(
      titleVal,
      contentVal,
      enabled,
      now,
      existing.id
    );
  } else {
    db.prepare(
      'INSERT INTO announcements (title, content, is_enabled, updated_at) VALUES (?, ?, ?, ?)'
    ).run(titleVal, contentVal, enabled, now);
  }

  res.json({ success: true, message: '公告已保存' });
});

// ========== 管理员：兑换码列表 ==========
router.get('/redemption-codes', authRequired, adminRequired, (req, res) => {
  const db = getDb();
  const { keyword, status } = req.query as { keyword?: string; status?: string };

  let sql = 'SELECT * FROM redemption_codes WHERE 1=1';
  const params: Array<string | number> = [];

  if (keyword && keyword.trim()) {
    sql += ' AND code LIKE ?';
    params.push(`%${keyword.trim().toUpperCase()}%`);
  }
  if (status === 'active') {
    sql += ' AND is_active = 1 AND is_used = 0';
  } else if (status === 'used') {
    sql += ' AND is_used = 1';
  } else if (status === 'disabled') {
    sql += ' AND is_active = 0';
  }

  sql += ' ORDER BY id DESC LIMIT 100';

  const rows = db.prepare(sql).all(...params) as Array<Record<string, unknown>>;

  const result = rows.map((r) => ({
    id: r.id,
    code: r.code,
    membershipLevel: r.membership_level,
    days: r.days,
    isActive: r.is_active === 1,
    isUsed: r.is_used === 1,
    usedBy: r.used_by,
    usedAt: r.used_at,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  }));

  res.json({ success: true, data: result });
});

// ========== 管理员：生成兑换码 ==========
router.post('/redemption-codes', authRequired, adminRequired, (req, res) => {
  const { level, days, count, prefix } = req.body as {
    level?: string;
    days?: number;
    count?: number;
    prefix?: string;
  };

  if (!level || !['plus', 'ultra'].includes(level)) {
    res.status(400).json({ success: false, message: '会员等级无效' });
    return;
  }
  if (typeof days !== 'number' || days <= 0) {
    res.status(400).json({ success: false, message: '天数无效' });
    return;
  }
  const codeCount = typeof count === 'number' && count > 0 && count <= 100 ? count : 1;

  const db = getDb();
  const now = Date.now();
  const generated: string[] = [];

  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const generateCode = () => {
    const p = (prefix || '').toUpperCase();
    let code = '';
    for (let i = 0; i < 12; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return p + code;
  };

  const insertStmt = db.prepare(
    'INSERT INTO redemption_codes (code, membership_level, days, is_active, is_used, created_at, updated_at) VALUES (?, ?, ?, 1, 0, ?, ?)'
  );

  for (let i = 0; i < codeCount; i++) {
    let code = generateCode();
    // 确保唯一
    let attempts = 0;
    while (attempts < 10) {
      const exists = db.prepare('SELECT id FROM redemption_codes WHERE code = ?').get(code);
      if (!exists) break;
      code = generateCode();
      attempts++;
    }
    insertStmt.run(code, level, days, now, now);
    generated.push(code);
  }

  res.json({
    success: true,
    message: `已生成 ${generated.length} 个兑换码`,
    data: generated,
  });
});

// ========== 管理员：停用/启用兑换码 ==========
router.post('/redemption-codes/:id/toggle', authRequired, adminRequired, (req, res) => {
  const codeId = Number(req.params.id);
  if (!codeId) {
    res.status(400).json({ success: false, message: '兑换码 ID 无效' });
    return;
  }

  const db = getDb();
  const code = db.prepare('SELECT id, is_active, is_used FROM redemption_codes WHERE id = ?').get(codeId) as
    | { id: number; is_active: number; is_used: number }
    | undefined;

  if (!code) {
    res.status(404).json({ success: false, message: '兑换码不存在' });
    return;
  }
  if (code.is_used === 1) {
    res.status(400).json({ success: false, message: '已兑换的码无法停用' });
    return;
  }

  const newActive = code.is_active === 1 ? 0 : 1;
  db.prepare('UPDATE redemption_codes SET is_active = ?, updated_at = ? WHERE id = ?').run(
    newActive,
    Date.now(),
    codeId
  );

  res.json({
    success: true,
    message: newActive === 1 ? '已启用' : '已停用',
    data: { isActive: newActive === 1 },
  });
});

// ========== 管理员：删除兑换码 ==========
router.delete('/redemption-codes/:id', authRequired, adminRequired, (req, res) => {
  const codeId = Number(req.params.id);
  if (!codeId) {
    res.status(400).json({ success: false, message: '兑换码 ID 无效' });
    return;
  }

  const db = getDb();
  db.prepare('DELETE FROM redemption_codes WHERE id = ?').run(codeId);
  res.json({ success: true, message: '已删除' });
});

// ========== 管理员：统计概览 ==========
router.get('/stats', authRequired, adminRequired, (_req, res) => {
  const db = getDb();

  const totalUsers = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  const activeUsers = (db.prepare('SELECT COUNT(*) as c FROM users WHERE is_active = 1').get() as { c: number }).c;
  const adminUsers = (db.prepare('SELECT COUNT(*) as c FROM users WHERE is_admin = 1').get() as { c: number }).c;
  const totalBooks = (db.prepare('SELECT COUNT(*) as c FROM books').get() as { c: number }).c;

  res.json({
    success: true,
    data: {
      totalUsers,
      activeUsers,
      adminUsers,
      totalBooks,
    },
  });
});

export default router;
