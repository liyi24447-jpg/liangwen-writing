import { Router } from 'express';
import { getDb } from '../db/index.js';
import { authRequired } from '../middleware/auth.js';
import type { IBookWork, IChapter, IVolume, ICharacterProfile } from '../types/book.js';

const router = Router();

// ========== 工具函数：组装作品完整数据 ==========
function assembleBook(bookRow: Record<string, unknown>): IBookWork {
  const db = getDb();
  const bookId = bookRow.id as string;

  // 书名候选
  const titleCandidates = db
    .prepare('SELECT title FROM book_title_candidates WHERE book_id = ? ORDER BY sort_order')
    .all(bookId) as Array<{ title: string }>;

  // 人物
  const characters = db
    .prepare('SELECT * FROM characters WHERE book_id = ? ORDER BY sort_order')
    .all(bookId) as Array<Record<string, unknown>>;

  const characterProfiles: ICharacterProfile[] = characters.map((c) => ({
    id: c.id as string,
    name: c.name as string,
    identity: (c.identity as string) || '',
    gender: (c.gender as string) || '',
    personality: (c.personality as string) || '',
    background: (c.background as string) || '',
    relationship: (c.relationship as string) || '',
    characterArc: (c.character_arc as string) || '',
    keyTraits: (c.key_traits as string) || '',
    extraFields: c.extra_fields ? JSON.parse(c.extra_fields as string) : [],
  }));

  // 卷
  const volumes = db
    .prepare('SELECT * FROM volumes WHERE book_id = ? ORDER BY sort_order')
    .all(bookId) as Array<Record<string, unknown>>;

  const volumeList: IVolume[] = volumes.map((v) => ({
    id: v.id as string,
    title: v.title as string,
    summary: (v.summary as string) || '',
    chapterCount: v.chapter_count as number,
    createdAt: v.created_at as number,
    updatedAt: v.updated_at as number,
  }));

  // 章节
  const chapters = db
    .prepare('SELECT * FROM chapters WHERE book_id = ? ORDER BY sort_order')
    .all(bookId) as Array<Record<string, unknown>>;

  const chapterList: IChapter[] = chapters.map((c) => ({
    id: c.id as string,
    title: c.title as string,
    summary: (c.summary as string) || '',
    wordCount: c.word_count as number,
    content: c.content as string,
    volumeId: (c.volume_id as string) || undefined,
    status: c.status as 'draft' | 'completed',
    createdAt: c.created_at as number,
    updatedAt: c.updated_at as number,
  }));

  return {
    id: bookId,
    title: bookRow.title as string,
    genre: bookRow.genre as string,
    categoryGroup: bookRow.category_group as 'male' | 'female',
    setting: bookRow.setting as string,
    characters: [], // 已弃用老字段，用 characterProfiles
    writingStyle: bookRow.writing_style as string,
    narrativePerspective: bookRow.narrative_perspective as 'first' | 'third',
    styleDescription: bookRow.style_description as string,
    styleGuide: (bookRow.style_guide as string) || undefined,
    synopsis: (bookRow.synopsis as string) || undefined,
    blurb: (bookRow.blurb as string) || undefined,
    blurbWordCount: (bookRow.blurb_word_count as string) || undefined,
    blurbFocus: (bookRow.blurb_focus as string) || undefined,
    titleCandidates: titleCandidates.map((t) => t.title),
    outline: (bookRow.outline as string) || undefined,
    characterProfiles,
    volumes: volumeList,
    chapters: chapterList,
    scriptContent: (bookRow.script_content as string) || undefined,
    wordCount: bookRow.word_count as number,
    chapterCount: bookRow.chapter_count as number,
    status: bookRow.status as 'active' | 'archived',
    createdAt: bookRow.created_at as number,
    updatedAt: bookRow.updated_at as number,
  };
}

// ========== 获取当前用户的所有作品 ==========
router.get('/', authRequired, (req, res) => {
  if (!req.user) return;
  const db = getDb();

  const bookRows = db
    .prepare('SELECT * FROM books WHERE user_id = ? AND status = ? ORDER BY updated_at DESC')
    .all(req.user.userId, 'active') as Array<Record<string, unknown>>;

  const books = bookRows.map((row) => assembleBook(row));
  res.json({ success: true, data: books });
});

// ========== 获取单个作品详情 ==========
router.get('/:id', authRequired, (req, res) => {
  if (!req.user) return;
  const db = getDb();
  const bookRow = db
    .prepare('SELECT * FROM books WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user.userId) as Record<string, unknown> | undefined;

  if (!bookRow) {
    res.status(404).json({ success: false, message: '作品不存在' });
    return;
  }

  const book = assembleBook(bookRow);
  res.json({ success: true, data: book });
});

// ========== 保存/更新作品（全量）==========
router.put('/:id', authRequired, (req, res) => {
  if (!req.user) return;
  const bookId = req.params.id;
  const book = req.body as IBookWork;
  const db = getDb();

  const now = Date.now();

  // 检查存在性
  const existing = db.prepare('SELECT id FROM books WHERE id = ? AND user_id = ?').get(bookId, req.user.userId);
  if (!existing) {
    res.status(404).json({ success: false, message: '作品不存在' });
    return;
  }

  const stmt = db.prepare(`
    UPDATE books SET
      title = ?, genre = ?, category_group = ?, setting = ?, writing_style = ?,
      narrative_perspective = ?, style_description = ?, style_guide = ?, synopsis = ?,
      blurb = ?, blurb_word_count = ?, blurb_focus = ?, outline = ?, script_content = ?,
      word_count = ?, chapter_count = ?, status = ?, updated_at = ?
    WHERE id = ? AND user_id = ?
  `);

  stmt.run(
    book.title || '未命名作品',
    book.genre || '玄幻',
    book.categoryGroup || 'male',
    book.setting || '',
    book.writingStyle || '朴实真挚',
    book.narrativePerspective || 'third',
    book.styleDescription || '',
    book.styleGuide || null,
    book.synopsis || null,
    book.blurb || null,
    book.blurbWordCount || null,
    book.blurbFocus || null,
    book.outline || null,
    book.scriptContent || null,
    book.wordCount || 0,
    book.chapterCount || 0,
    book.status || 'active',
    now,
    bookId,
    req.user.userId
  );

  // 书名候选：先删后插
  db.prepare('DELETE FROM book_title_candidates WHERE book_id = ?').run(bookId);
  if (book.titleCandidates && book.titleCandidates.length > 0) {
    const insertTitle = db.prepare(
      'INSERT INTO book_title_candidates (book_id, title, sort_order) VALUES (?, ?, ?)'
    );
    book.titleCandidates.forEach((title, i) => {
      insertTitle.run(bookId, title, i);
    });
  }

  // 人物：先删后插
  db.prepare('DELETE FROM characters WHERE book_id = ?').run(bookId);
  if (book.characterProfiles && book.characterProfiles.length > 0) {
    const insertChar = db.prepare(`
      INSERT INTO characters (id, book_id, name, identity, gender, personality, background,
        relationship, character_arc, key_traits, extra_fields, sort_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    book.characterProfiles.forEach((c, i) => {
      insertChar.run(
        c.id,
        bookId,
        c.name,
        c.identity || null,
        c.gender || null,
        c.personality || null,
        c.background || null,
        c.relationship || null,
        c.characterArc || null,
        c.keyTraits || null,
        c.extraFields ? JSON.stringify(c.extraFields) : null,
        i,
        now,
        now
      );
    });
  }

  // 卷：先删后插
  db.prepare('DELETE FROM volumes WHERE book_id = ?').run(bookId);
  if (book.volumes && book.volumes.length > 0) {
    const insertVol = db.prepare(`
      INSERT INTO volumes (id, book_id, title, summary, chapter_count, sort_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    book.volumes.forEach((v, i) => {
      insertVol.run(v.id, bookId, v.title, v.summary || null, v.chapterCount || 0, i, now, now);
    });
  }

  // 章节：先删后插
  db.prepare('DELETE FROM chapters WHERE book_id = ?').run(bookId);
  if (book.chapters && book.chapters.length > 0) {
    const insertCh = db.prepare(`
      INSERT INTO chapters (id, book_id, volume_id, title, summary, word_count, content, status, sort_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    book.chapters.forEach((c, i) => {
      insertCh.run(
        c.id,
        bookId,
        c.volumeId || null,
        c.title,
        c.summary || null,
        c.wordCount || 0,
        c.content || '',
        c.status || 'draft',
        i,
        now,
        now
      );
    });
  }

  // 返回更新后的完整数据
  const updatedRow = db.prepare('SELECT * FROM books WHERE id = ?').get(bookId) as Record<string, unknown>;
  const result = assembleBook(updatedRow);

  res.json({ success: true, data: result, message: '保存成功' });
});

// ========== 创建作品 ==========
router.post('/', authRequired, (req, res) => {
  if (!req.user) return;
  const book = req.body as IBookWork;
  const db = getDb();
  const now = Date.now();
  const bookId = book.id || `book_${now}_${Math.random().toString(36).slice(2, 8)}`;

  db.prepare(`
    INSERT INTO books
      (id, user_id, title, genre, category_group, setting, writing_style, narrative_perspective,
       style_description, style_guide, synopsis, blurb, blurb_word_count, blurb_focus, outline,
       script_content, word_count, chapter_count, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    bookId,
    req.user.userId,
    book.title || '未命名作品',
    book.genre || '玄幻',
    book.categoryGroup || 'male',
    book.setting || '',
    book.writingStyle || '朴实真挚',
    book.narrativePerspective || 'third',
    book.styleDescription || '',
    book.styleGuide || null,
    book.synopsis || null,
    book.blurb || null,
    book.blurbWordCount || null,
    book.blurbFocus || null,
    book.outline || null,
    book.scriptContent || null,
    book.wordCount || 0,
    book.chapterCount || 0,
    book.status || 'active',
    now,
    now
  );

  // 书名候选
  if (book.titleCandidates && book.titleCandidates.length > 0) {
    const insertTitle = db.prepare(
      'INSERT INTO book_title_candidates (book_id, title, sort_order) VALUES (?, ?, ?)'
    );
    book.titleCandidates.forEach((title, i) => {
      insertTitle.run(bookId, title, i);
    });
  }

  // 人物
  if (book.characterProfiles && book.characterProfiles.length > 0) {
    const insertChar = db.prepare(`
      INSERT INTO characters (id, book_id, name, identity, gender, personality, background,
        relationship, character_arc, key_traits, extra_fields, sort_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    book.characterProfiles.forEach((c, i) => {
      insertChar.run(
        c.id,
        bookId,
        c.name,
        c.identity || null,
        c.gender || null,
        c.personality || null,
        c.background || null,
        c.relationship || null,
        c.characterArc || null,
        c.keyTraits || null,
        c.extraFields ? JSON.stringify(c.extraFields) : null,
        i,
        now,
        now
      );
    });
  }

  // 卷
  if (book.volumes && book.volumes.length > 0) {
    const insertVol = db.prepare(`
      INSERT INTO volumes (id, book_id, title, summary, chapter_count, sort_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    book.volumes.forEach((v, i) => {
      insertVol.run(v.id, bookId, v.title, v.summary || null, v.chapterCount || 0, i, now, now);
    });
  }

  // 章节
  if (book.chapters && book.chapters.length > 0) {
    const insertCh = db.prepare(`
      INSERT INTO chapters (id, book_id, volume_id, title, summary, word_count, content, status, sort_order, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    book.chapters.forEach((c, i) => {
      insertCh.run(
        c.id,
        bookId,
        c.volumeId || null,
        c.title,
        c.summary || null,
        c.wordCount || 0,
        c.content || '',
        c.status || 'draft',
        i,
        now,
        now
      );
    });
  }

  const createdRow = db.prepare('SELECT * FROM books WHERE id = ?').get(bookId) as Record<string, unknown>;
  const result = assembleBook(createdRow);

  res.json({ success: true, data: result, message: '创建成功' });
});

// ========== 删除作品（软删除，改 status）==========
router.delete('/:id', authRequired, (req, res) => {
  if (!req.user) return;
  const db = getDb();

  const result = db
    .prepare("UPDATE books SET status = 'archived', updated_at = ? WHERE id = ? AND user_id = ?")
    .run(Date.now(), req.params.id, req.user.userId);

  if (result.changes === 0) {
    res.status(404).json({ success: false, message: '作品不存在' });
    return;
  }

  res.json({ success: true, message: '作品已删除' });
});

export default router;
