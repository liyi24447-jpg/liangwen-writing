import { Router } from 'express';
import { getDb } from '../db/index.js';
import { signToken, hashPassword, verifyPassword, authRequired } from '../middleware/auth.js';

const router = Router();

// ========== 注册 ==========
router.post('/register', (req, res) => {
  const { account, password } = req.body as { account?: string; password?: string };

  if (!account || !account.trim()) {
    res.status(400).json({ success: false, message: '账号不能为空' });
    return;
  }
  if (!password) {
    res.status(400).json({ success: false, message: '密码不能为空' });
    return;
  }
  const trimmedAccount = account.trim();
  if (trimmedAccount.length < 3) {
    res.status(400).json({ success: false, message: '账号长度至少 3 位' });
    return;
  }
  if (password.length < 6) {
    res.status(400).json({ success: false, message: '密码长度至少 6 位' });
    return;
  }

  const db = getDb();

  // 检查账号是否存在
  const existing = db.prepare('SELECT id FROM users WHERE account = ?').get(trimmedAccount);
  if (existing) {
    res.status(400).json({ success: false, message: '该账号已存在，请直接登录或更换账号' });
    return;
  }

  const now = Date.now();
  const passwordHash = hashPassword(password);

  const info = db
    .prepare(
      'INSERT INTO users (account, password_hash, is_admin, is_active, created_at, updated_at) VALUES (?, ?, 0, 1, ?, ?)'
    )
    .run(trimmedAccount, passwordHash, now, now);

  const userId = Number(info.lastInsertRowid);

  // 初始化默认权限（全部启用）
  db.prepare(
    `INSERT INTO user_permissions 
    (user_id, can_write_short, can_disassemble, can_hot_rank, can_optimize, can_workbench, can_upload_continue, created_at, updated_at)
    VALUES (?, 1, 1, 1, 1, 1, 1, ?, ?)`
  ).run(userId, now, now);

  // 初始化会员字段（users 表已有默认值，这里确保写入）
  db.prepare('UPDATE users SET membership_level = ?, membership_expire_at = ?, updated_at = ? WHERE id = ?').run(
    'none',
    0,
    now,
    userId
  );

  // 自动登录
  const token = signToken({ userId, account: trimmedAccount, isAdmin: false });

  res.json({
    success: true,
    message: '注册成功',
    data: {
      token,
      user: { id: userId, account: trimmedAccount, isAdmin: false },
    },
  });
});

// ========== 登录 ==========
router.post('/login', (req, res) => {
  const { account, password } = req.body as { account?: string; password?: string };

  if (!account || !account.trim()) {
    res.status(400).json({ success: false, message: '请输入账号' });
    return;
  }
  if (!password) {
    res.status(400).json({ success: false, message: '请输入密码' });
    return;
  }

  const db = getDb();
  const user = db
    .prepare('SELECT id, account, password_hash, is_admin, is_active FROM users WHERE account = ?')
    .get(account.trim()) as
    | { id: number; account: string; password_hash: string; is_admin: number; is_active: number }
    | undefined;

  if (!user) {
    res.status(400).json({ success: false, message: '账号不存在，请先注册' });
    return;
  }

  if (!user.is_active) {
    res.status(403).json({ success: false, message: '账号已被禁用，请联系管理员' });
    return;
  }

  if (!verifyPassword(password, user.password_hash)) {
    res.status(400).json({ success: false, message: '密码错误，请重试' });
    return;
  }

  const token = signToken({ userId: user.id, account: user.account, isAdmin: user.is_admin === 1 });

  res.json({
    success: true,
    message: '登录成功',
    data: {
      token,
      user: {
        id: user.id,
        account: user.account,
        isAdmin: user.is_admin === 1,
      },
    },
  });
});

// ========== 获取当前用户信息 + 权限 + 会员 ==========
router.get('/me', authRequired, (req, res) => {
  if (!req.user) return;
  const db = getDb();

  // 获取用户信息 + 会员
  const userRow = db
    .prepare('SELECT membership_level, membership_expire_at FROM users WHERE id = ?')
    .get(req.user.userId) as { membership_level: string; membership_expire_at: number } | undefined;

  // 获取用户权限
  const perms = db
    .prepare('SELECT * FROM user_permissions WHERE user_id = ?')
    .get(req.user.userId) as Record<string, unknown> | undefined;

  const now = Date.now();
  const rawLevel = userRow?.membership_level || 'none';
  const rawExpire = userRow?.membership_expire_at || 0;
  // 如果已过期，等级降级为 none
  const membershipLevel = rawExpire > 0 && rawExpire < now ? 'none' : rawLevel;
  const membershipExpireAt = membershipLevel === 'none' ? 0 : rawExpire;

  res.json({
    success: true,
    data: {
      user: {
        id: req.user.userId,
        account: req.user.account,
        isAdmin: req.user.isAdmin,
        membershipLevel,
        membershipExpireAt,
      },
      permissions: perms
        ? {
            canWriteShort: perms.can_write_short === 1,
            canDisassemble: perms.can_disassemble === 1,
            canHotRank: perms.can_hot_rank === 1,
            canOptimize: perms.can_optimize === 1,
            canWorkbench: perms.can_workbench === 1,
            canUploadContinue: perms.can_upload_continue === 1,
          }
        : {
            canWriteShort: true,
            canDisassemble: true,
            canHotRank: true,
            canOptimize: true,
            canWorkbench: true,
            canUploadContinue: true,
          },
    },
  });
});

// ========== 修改密码 ==========
router.post('/change-password', authRequired, (req, res) => {
  if (!req.user) return;
  const { oldPassword, newPassword } = req.body as { oldPassword?: string; newPassword?: string };

  if (!oldPassword || !newPassword) {
    res.status(400).json({ success: false, message: '旧密码和新密码都不能为空' });
    return;
  }
  if (newPassword.length < 6) {
    res.status(400).json({ success: false, message: '新密码长度至少 6 位' });
    return;
  }

  const db = getDb();
  const user = db
    .prepare('SELECT password_hash FROM users WHERE id = ?')
    .get(req.user.userId) as { password_hash: string } | undefined;

  if (!user || !verifyPassword(oldPassword, user.password_hash)) {
    res.status(400).json({ success: false, message: '旧密码错误' });
    return;
  }

  const newHash = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
    newHash,
    Date.now(),
    req.user.userId
  );

  res.json({ success: true, message: '密码修改成功' });
});

export default router;
