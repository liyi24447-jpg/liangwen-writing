import { Router } from 'express';
import { getDb } from '../db/index.js';
import { authRequired } from '../middleware/auth.js';
import type { Request } from 'express';

const router = Router();

// ========== 兑换兑换码 ==========
router.post('/redeem', authRequired, (req: Request, res) => {
  if (!req.user) return;
  const { code } = req.body as { code?: string };

  if (!code || !code.trim()) {
    res.status(400).json({ success: false, message: '请输入兑换码' });
    return;
  }

  const db = getDb();
  const trimmedCode = code.trim().toUpperCase();

  const redemption = db
    .prepare('SELECT * FROM redemption_codes WHERE code = ?')
    .get(trimmedCode) as Record<string, unknown> | undefined;

  if (!redemption) {
    res.status(400).json({ success: false, message: '兑换码无效，请检查后重试' });
    return;
  }

  if (redemption.is_active !== 1) {
    res.status(400).json({ success: false, message: '该兑换码已停用' });
    return;
  }

  if (redemption.is_used === 1) {
    res.status(400).json({ success: false, message: '该兑换码已被使用' });
    return;
  }

  const now = Date.now();
  const level = redemption.membership_level as string;
  const days = redemption.days as number;
  const extendMs = days * 24 * 60 * 60 * 1000;

  // 获取当前用户会员信息
  const user = db
    .prepare('SELECT membership_level, membership_expire_at FROM users WHERE id = ?')
    .get(req.user.userId) as { membership_level: string; membership_expire_at: number } | undefined;

  if (!user) {
    res.status(400).json({ success: false, message: '用户不存在' });
    return;
  }

  // 计算新的到期时间
  let newExpireAt: number;
  const currentLevel = user.membership_level;
  const currentExpire = user.membership_expire_at;

  if (currentLevel === 'none' || currentExpire <= now) {
    // 当前不是会员或已过期，从现在开始计算
    newExpireAt = now + extendMs;
  } else if (currentLevel === level) {
    // 同等级会员，在现有基础上延长
    newExpireAt = currentExpire + extendMs;
  } else {
    // 不同等级：
    // - 若兑换的是 ultra 且当前是 plus：升级为 ultra，在 ultra 上重新计算（从现在起）
    // - 若兑换的是 plus 且当前是 ultra：plus 时间追加到 ultra 到期后（降级缓冲期）
    if (level === 'ultra') {
      newExpireAt = now + extendMs;
    } else {
      // plus 追加在 ultra 到期之后
      newExpireAt = currentExpire + extendMs;
    }
  }

  // 确定最终等级（取较高等级，ultra > plus）
  let finalLevel = currentLevel;
  if (level === 'ultra' || currentLevel === 'ultra') {
    finalLevel = 'ultra';
  } else if (level === 'plus' || currentLevel === 'plus') {
    finalLevel = 'plus';
  }

  // 特殊：如果当前 ultra 未过期但兑换 plus，保持 ultra 等级不变，时间不叠加
  if (currentLevel === 'ultra' && currentExpire > now && level === 'plus') {
    finalLevel = 'ultra';
    newExpireAt = currentExpire + extendMs; // plus 作为延期追加
  }

  // 更新用户会员信息
  db.prepare('UPDATE users SET membership_level = ?, membership_expire_at = ?, updated_at = ? WHERE id = ?').run(
    finalLevel,
    newExpireAt,
    now,
    req.user.userId
  );

  // 标记兑换码已使用
  db.prepare('UPDATE redemption_codes SET is_used = 1, used_by = ?, used_at = ?, updated_at = ? WHERE code = ?').run(
    req.user.userId,
    now,
    now,
    trimmedCode
  );

  res.json({
    success: true,
    message: `兑换成功！已开通 ${level === 'ultra' ? 'Ultra' : 'Plus'} 会员 ${days} 天`,
    data: {
      membershipLevel: finalLevel,
      membershipExpireAt: newExpireAt,
    },
  });
});

export default router;
