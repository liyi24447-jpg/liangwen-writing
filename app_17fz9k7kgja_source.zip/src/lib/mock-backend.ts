import Dexie, { type Table } from 'dexie';
import bcrypt from 'bcryptjs';
import { logger } from '@lark-apaas/client-toolkit-lite';
import type { IBookWork } from '@/data/novel';

// 类型定义（与 api-client.ts 保持一致，避免循环依赖）
interface UserPermissions {
  canWriteShort: boolean;
  canDisassemble: boolean;
  canHotRank: boolean;
  canOptimize: boolean;
  canWorkbench: boolean;
  canUploadContinue: boolean;
}

interface UserInfo {
  id: number;
  account: string;
  isAdmin: boolean;
  membershipLevel: 'none' | 'plus' | 'ultra';
  membershipExpireAt: number;
}

interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
}

// JWT 密钥（仅前端模拟用，真实场景应由后端保管）
const JWT_SECRET = 'liangwen_mock_backend_secret_key_2024';
const SALT_ROUNDS = 10;

// ========== 数据库表定义 ==========

interface DBUser {
  id?: number;
  account: string;
  passwordHash: string;
  isAdmin: number; // 0 or 1
  status: 'active' | 'disabled';
  membershipLevel?: 'none' | 'plus' | 'ultra';
  membershipExpireAt?: number;
  createdAt: number;
  updatedAt: number;
}

interface DBPermission {
  id?: number;
  userId: number;
  canWriteShort: number;
  canDisassemble: number;
  canHotRank: number;
  canOptimize: number;
  canWorkbench: number;
  canUploadContinue: number;
  /** 是否由管理员显式配置过。0=历史默认数据/未配置过，1=管理员主动保存过 */
  configuredByAdmin: number;
  updatedAt: number;
}

interface DBLevelPermission {
  id?: number;
  /** 会员等级：none / plus / ultra */
  level: string;
  canWriteShort: number;
  canDisassemble: number;
  canHotRank: number;
  canOptimize: number;
  canWorkbench: number;
  canUploadContinue: number;
  /** 是否由管理员显式保存过。0=历史默认/未配置过，1=管理员主动保存过 */
  configuredByAdmin: number;
  updatedAt: number;
}

interface DBBookshelf {
  bookId: string;
  userId: number;
  data: string; // JSON string of IBookWork
  updatedAt: number;
  createdAt: number;
}

interface DBRedemptionCode {
  id?: number;
  code: string;
  membershipLevel: 'plus' | 'ultra';
  days: number;
  isActive: number; // 0 or 1
  isUsed: number; // 0 or 1
  usedBy?: number;
  usedAt?: number;
  createdAt: number;
  updatedAt: number;
}

interface DBDailyWordUsage {
  id?: number;
  userId: number;
  /** YYYY-MM-DD 格式的日期键 */
  dateKey: string;
  /** 当日累计生成正文字数 */
  wordCount: number;
  updatedAt: number;
}

interface DBAnnouncement {
  id?: number;
  title: string;
  content: string;
  isEnabled: number; // 0 or 1
  updatedAt: number;
}

class MockBackendDB extends Dexie {
  users!: Table<DBUser, number>;
  permissions!: Table<DBPermission, number>;
  levelPermissions!: Table<DBLevelPermission, number>;
  bookshelves!: Table<DBBookshelf, string>;
  redemptionCodes!: Table<DBRedemptionCode, number>;
  announcements!: Table<DBAnnouncement, number>;
  dailyWordUsage!: Table<DBDailyWordUsage, number>;

  constructor() {
    super('liangwen_db');
    // v1: 初始版本（部分老用户可能只有 account/status/createdAt 三个索引，缺 isAdmin）
    this.version(1).stores({
      users: '++id, account, status, createdAt',
      permissions: '++id, userId',
      bookshelves: 'bookId, userId, updatedAt',
    });
    // v2: 为 users 表补充 isAdmin 索引，支持管理员查询
    this.version(2).stores({
      users: '++id, account, status, isAdmin, createdAt',
    });
    // v3: 新增兑换码表、公告表
    this.version(3).stores({
      redemptionCodes: '++id, code, isActive, isUsed, createdAt',
      announcements: '++id, isEnabled, updatedAt',
    });
    // v4: 新增每日字数统计表
    this.version(4).stores({
      dailyWordUsage: '++id, userId, dateKey, [userId+dateKey]',
    });
    // v5: 新增等级权限配置表
    this.version(5).stores({
      levelPermissions: '++id, level',
    });
    // v6: 等级权限表新增 configuredByAdmin 字段，区分「历史默认全开数据」与「管理员显式保存」
    this.version(6).stores({
      levelPermissions: '++id, level',
    }).upgrade(async (trans) => {
      // 历史数据标记为未配置过，后续读取会回退到默认等级映射
      const rows = await trans.table('levelPermissions').toArray();
      for (const row of rows) {
        if (row.configuredByAdmin === undefined) {
          await trans.table('levelPermissions').update(row.id, { configuredByAdmin: 0 });
        }
      }
    });

    // 版本冲突或数据库损坏时自动删除并重建，避免用户因旧版本 schema 卡住
    this.on('populate', () => {
      logger.info('[mock-backend] 数据库首次创建，开始初始化');
    });
  }
}

let db: MockBackendDB;

/**
 * 校验数据库索引完整性。若关键索引缺失（旧版本残留 schema），删除并重建。
 */
async function validateAndRebuildIfNeeded(instance: MockBackendDB): Promise<MockBackendDB> {
  try {
    // 检查 users 表是否存在 isAdmin 索引
    const usersTable = (instance as unknown as { tables: Array<{ name: string; schema: { indexes: Array<{ name: string }> } }> }).tables.find(
      (t) => t.name === 'users'
    );
    let needRebuild = false;
    if (usersTable) {
      const indexNames = usersTable.schema.indexes.map((i) => i.name);
      if (!indexNames.includes('isAdmin')) {
        needRebuild = true;
      }
    } else {
      needRebuild = true;
    }
    // 检查 v3 新增的兑换码表、公告表是否存在
    // 检查 v4 新增的每日字数统计表是否存在
    const tables = (instance as unknown as { tables: Array<{ name: string }> }).tables.map((t) => t.name);
    if (
      !tables.includes('redemptionCodes') ||
      !tables.includes('announcements') ||
      !tables.includes('dailyWordUsage') ||
      !tables.includes('levelPermissions')
    ) {
      needRebuild = true;
    }
    if (needRebuild) {
      logger.warn('[mock-backend] 数据库表结构不完整，重建数据库');
      await instance.close();
      await Dexie.delete('liangwen_db');
      const newDb = new MockBackendDB();
      await newDb.open();
      logger.info('[mock-backend] 数据库重建完成');
      return newDb;
    }
    return instance;
  } catch (err) {
    logger.warn('[mock-backend] 索引校验失败，尝试重建:', String(err));
    try {
      await instance.close();
    } catch {
      /* ignore */
    }
    try {
      await Dexie.delete('liangwen_db');
    } catch {
      /* ignore */
    }
    const newDb = new MockBackendDB();
    await newDb.open();
    return newDb;
  }
}

try {
  db = new MockBackendDB();
  // 探测数据库能否正常打开；若版本冲突或损坏，删除后重建
  db.open()
    .then(() => {
      // 打开成功后校验索引完整性，缺失则重建
      validateAndRebuildIfNeeded(db).then((newDb) => {
        if (newDb !== db) {
          db = newDb;
          // 重置 initPromise，让后续请求走新建库的初始化流程
          initPromise = null;
        }
      });
    })
    .catch(async (err) => {
      logger.warn('[mock-backend] 数据库打开失败，尝试重建:', String(err));
      try {
        await db.close();
      } catch {
        /* ignore */
      }
      try {
        await Dexie.delete('liangwen_db');
      } catch {
        /* ignore */
      }
      db = new MockBackendDB();
      logger.info('[mock-backend] 数据库已重建');
    });
} catch (err) {
  logger.error('[mock-backend] 数据库初始化异常:', String(err));
  db = new MockBackendDB();
}

// ========== 初始化：默认管理员 ==========

async function ensureDefaultAdmin() {
  const existing = await db.users.where('account').equals('admin').first();
  if (existing) return;

  const passwordHash = await bcrypt.hash('admin123456', SALT_ROUNDS);
  const now = Date.now();
  const adminId = await db.users.add({
    account: 'admin',
    passwordHash,
    isAdmin: 1,
    status: 'active',
    createdAt: now,
    updatedAt: now,
  });

  await db.permissions.add({
    userId: adminId,
    canWriteShort: 1,
    canDisassemble: 1,
    canHotRank: 1,
    canOptimize: 1,
    canWorkbench: 1,
    canUploadContinue: 1,
    configuredByAdmin: 1,
    updatedAt: now,
  });

  logger.info('[mock-backend] 默认管理员已创建: admin / admin123456');
}

// 首次加载时初始化
let initPromise: Promise<void> | null = null;
function getInitPromise() {
  if (!initPromise) {
    initPromise = (async () => {
      // 确保数据库已打开，若打开失败则等待重建完成
      try {
        await db.open();
        // 再次校验索引完整性（防御性检查：首次打开前可能未完成校验）
        const validated = await validateAndRebuildIfNeeded(db);
        if (validated !== db) {
          db = validated;
        }
      } catch (err) {
        logger.error('[mock-backend] 数据库打开失败:', String(err));
        throw new Error('本地数据存储初始化失败，请刷新页面重试');
      }
      await ensureDefaultAdmin();
    })();
  }
  return initPromise;
}

// ========== 工具函数 ==========

// ========== JWT 工具（浏览器端 Web Crypto 实现） ==========

function base64UrlEncode(data: ArrayBuffer | string): string {
  let base64: string;
  if (typeof data === 'string') {
    base64 = btoa(unescape(encodeURIComponent(data)));
  } else {
    const bytes = new Uint8Array(data);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    base64 = btoa(binary);
  }
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlDecode(str: string): Uint8Array {
  const base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

interface JwtPayload {
  id: number;
  account: string;
  isAdmin: boolean;
  exp: number;
  iat: number;
}

async function getCryptoKey(): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(JWT_SECRET);
  return crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify']
  );
}

async function generateToken(user: DBUser): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const payload: JwtPayload = {
    id: user.id!,
    account: user.account,
    isAdmin: !!user.isAdmin,
    iat: now,
    exp: now + 7 * 24 * 60 * 60, // 7 天
  };

  const header = { alg: 'HS256', typ: 'JWT' };
  const headerEncoded = base64UrlEncode(JSON.stringify(header));
  const payloadEncoded = base64UrlEncode(JSON.stringify(payload));
  const data = `${headerEncoded}.${payloadEncoded}`;

  const key = await getCryptoKey();
  const encoder = new TextEncoder();
  const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(data));
  const signatureEncoded = base64UrlEncode(signature);

  return `${data}.${signatureEncoded}`;
}

async function verifyToken(token: string): Promise<JwtPayload | null> {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [headerEncoded, payloadEncoded, signatureEncoded] = parts;
    const data = `${headerEncoded}.${payloadEncoded}`;

    const key = await getCryptoKey();
    const encoder = new TextEncoder();
    const signatureBytes = base64UrlDecode(signatureEncoded);
    const signatureBuffer = signatureBytes.buffer.slice(
      signatureBytes.byteOffset,
      signatureBytes.byteOffset + signatureBytes.byteLength
    ) as ArrayBuffer;

    const valid = await crypto.subtle.verify(
      'HMAC',
      key,
      signatureBuffer,
      encoder.encode(data)
    );

    if (!valid) return null;

    const payloadBytes = base64UrlDecode(payloadEncoded);
    const payloadStr = new TextDecoder().decode(payloadBytes);
    const payload = JSON.parse(payloadStr) as JwtPayload;

    // 检查过期
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

function userToInfo(user: DBUser): UserInfo {
  return {
    id: user.id!,
    account: user.account,
    isAdmin: !!user.isAdmin,
    membershipLevel: user.membershipLevel || 'none',
    membershipExpireAt: user.membershipExpireAt || 0,
  };
}

function permissionRowToObj(row: DBPermission): UserPermissions {
  return {
    canWriteShort: !!row.canWriteShort,
    canDisassemble: !!row.canDisassemble,
    canHotRank: !!row.canHotRank,
    canOptimize: !!row.canOptimize,
    canWorkbench: !!row.canWorkbench,
    canUploadContinue: !!row.canUploadContinue,
  };
}

function levelPermRowToObj(row: DBLevelPermission): UserPermissions {
  return {
    canWriteShort: !!row.canWriteShort,
    canDisassemble: !!row.canDisassemble,
    canHotRank: !!row.canHotRank,
    canOptimize: !!row.canOptimize,
    canWorkbench: !!row.canWorkbench,
    canUploadContinue: !!row.canUploadContinue,
  };
}

const ALL_PERMS_ON: UserPermissions = {
  canWriteShort: true,
  canDisassemble: true,
  canHotRank: true,
  canOptimize: true,
  canWorkbench: true,
  canUploadContinue: true,
};

const ALL_PERMS_OFF: UserPermissions = {
  canWriteShort: false,
  canDisassemble: false,
  canHotRank: false,
  canOptimize: false,
  canWorkbench: false,
  canUploadContinue: false,
};

const NONE_LEVEL_PERMS: UserPermissions = {
  canWriteShort: false,
  canDisassemble: false,
  canHotRank: true,
  canOptimize: false,
  canWorkbench: false,
  canUploadContinue: false,
};

const PLUS_LEVEL_PERMS: UserPermissions = {
  canWriteShort: false,
  canDisassemble: true,
  canHotRank: true,
  canOptimize: true,
  canWorkbench: true,
  canUploadContinue: false,
};

const DEFAULT_LEVEL_PERMS: Record<string, UserPermissions> = {
  none: NONE_LEVEL_PERMS,
  plus: PLUS_LEVEL_PERMS,
  ultra: ALL_PERMS_ON,
};

async function getLevelPermissions(level: string): Promise<UserPermissions> {
  const row = await db.levelPermissions.where('level').equals(level).first();
  // 仅当等级权限被管理员显式保存过（configuredByAdmin=1）才生效
  // 老数据或未配置过的等级统一走 DEFAULT_LEVEL_PERMS
  if (row && row.configuredByAdmin === 1) return levelPermRowToObj(row);
  return DEFAULT_LEVEL_PERMS[level] || ALL_PERMS_ON;
}

/**
 * 按账号等级计算最终权限：等级权限为基底，只有被管理员显式配置过的账号（configuredByAdmin=1）才覆盖等级配置。
 * 老数据（注册时默认写死全开的行，configuredByAdmin=0/缺失）不覆盖等级权限，纯继承等级配置，
 * 以支持管理员在「会员权限」后台统一按等级开关功能。
 */
async function getUserPermissions(userId: number, userLevel?: string): Promise<UserPermissions> {
  const row = await db.permissions.where('userId').equals(userId).first();
  const level = userLevel || 'none';
  const levelPerm = await getLevelPermissions(level);
  if (!row) {
    // 账号没有单独配置：纯等级权限生效
    return levelPerm;
  }
  // 仅当账号被管理员显式配置过，才用账号行覆盖等级权限
  if (!row.configuredByAdmin) {
    return levelPerm;
  }
  const userPerm = permissionRowToObj(row);
  return { ...levelPerm, ...userPerm };
}

async function getCurrentUserFromToken(token: string): Promise<DBUser | null> {
  const decoded = await verifyToken(token);
  if (!decoded) return null;
  const user = await db.users.get(decoded.id);
  return user || null;
}

// ========== 认证接口 ==========

export async function mockLogin(account: string, password: string): Promise<ApiResponse<{ token: string; user: UserInfo }>> {
  await getInitPromise();
  const user = await db.users.where('account').equals(account).first();
  if (!user) {
    return { success: false, message: '账号或密码错误' };
  }
  if (user.status === 'disabled') {
    return { success: false, message: '账号已被禁用，请联系管理员' };
  }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return { success: false, message: '账号或密码错误' };
  }
  const token = await generateToken(user);
  return {
    success: true,
    message: '登录成功',
    data: { token, user: userToInfo(user) },
  };
}

export async function mockRegister(account: string, password: string): Promise<ApiResponse<{ token: string; user: UserInfo }>> {
  await getInitPromise();
  if (!account || account.length < 3) {
    return { success: false, message: '账号至少3个字符' };
  }
  if (!password || password.length < 6) {
    return { success: false, message: '密码至少6个字符' };
  }
  const existing = await db.users.where('account').equals(account).first();
  if (existing) {
    return { success: false, message: '账号已存在' };
  }
  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  const now = Date.now();
  const id = await db.users.add({
    account,
    passwordHash,
    isAdmin: 0,
    status: 'active',
    createdAt: now,
    updatedAt: now,
  });
  // 注意：新注册用户不在 permissions 表写入默认全开行
  // 用户实际权限 = 等级权限（管理员在后台配置） + 账号单独配置（管理员为该账号单独设置时才写入）
  // 未单独配置过的账号纯继承等级权限，以支持等级级别的统一开关控制
  const user = (await db.users.get(id))!;
  const token = await generateToken(user);
  logger.info('[mock-backend] 新用户注册:', account);
  return {
    success: true,
    message: '注册成功',
    data: { token, user: userToInfo(user) },
  };
}

export async function mockMe(token: string): Promise<ApiResponse<{ user: UserInfo; permissions: UserPermissions }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录或登录已过期' };
  }
  if (user.status === 'disabled') {
    return { success: false, message: '账号已被禁用' };
  }
  const level = user.membershipLevel || 'none';
  const permissions = await getUserPermissions(user.id!, level);
  return {
    success: true,
    message: 'ok',
    data: { user: userToInfo(user), permissions },
  };
}

export async function mockChangePassword(token: string, oldPassword: string, newPassword: string): Promise<ApiResponse> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const valid = await bcrypt.compare(oldPassword, user.passwordHash);
  if (!valid) {
    return { success: false, message: '原密码错误' };
  }
  if (newPassword.length < 6) {
    return { success: false, message: '新密码至少6个字符' };
  }
  const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
  await db.users.update(user.id!, { passwordHash, updatedAt: Date.now() });
  return { success: true, message: '密码修改成功' };
}

// ========== 管理后台接口 ==========

interface AdminUserListItem {
  id: number;
  account: string;
  isAdmin: boolean;
  isActive: boolean;
  membershipLevel: 'none' | 'plus' | 'ultra';
  membershipExpireAt: number;
  createdAt: number;
  updatedAt: number;
  bookCount: number;
  permissions: UserPermissions;
}

export async function mockAdminStats(token: string): Promise<ApiResponse<{
  totalUsers: number;
  activeUsers: number;
  adminUsers: number;
  totalBooks: number;
}>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const totalUsers = await db.users.count();
  const activeUsers = await db.users.where('status').equals('active').count();
  const adminUsers = await db.users.where('isAdmin').equals(1).count();
  const totalBooks = await db.bookshelves.count();
  return {
    success: true,
    message: 'ok',
    data: { totalUsers, activeUsers, adminUsers, totalBooks },
  };
}

export async function mockAdminUserList(
  token: string,
  keyword?: string
): Promise<ApiResponse<{ users: AdminUserListItem[] }>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  let allUsers = await db.users.toArray();
  if (keyword && keyword.trim()) {
    const kw = keyword.toLowerCase();
    allUsers = allUsers.filter((u) => u.account.toLowerCase().includes(kw));
  }
  allUsers.sort((a, b) => b.createdAt - a.createdAt);

  const result: AdminUserListItem[] = [];
  for (const user of allUsers) {
    const bookCount = await db.bookshelves.where('userId').equals(user.id!).count();
    const mLevel = user.membershipLevel || 'none';
    const mExpire = user.membershipExpireAt || 0;
    const effectiveLevel = mExpire > 0 && mExpire < Date.now() ? 'none' : mLevel;
    const perms = await getUserPermissions(user.id!, effectiveLevel);
    result.push({
      id: user.id!,
      account: user.account,
      isAdmin: !!user.isAdmin,
      isActive: user.status === 'active',
      membershipLevel: effectiveLevel as 'none' | 'plus' | 'ultra',
      membershipExpireAt: effectiveLevel === 'none' ? 0 : mExpire,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
      bookCount,
      permissions: perms,
    });
  }
  return { success: true, message: 'ok', data: { users: result } };
}

export async function mockAdminUserDisable(
  token: string,
  userId: number,
  disabled: boolean
): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  if (userId === adminUser.id) {
    return { success: false, message: '不能禁用自己的账号' };
  }
  await db.users.update(userId, {
    status: disabled ? 'disabled' : 'active',
    updatedAt: Date.now(),
  });
  return { success: true, message: disabled ? '已禁用' : '已启用' };
}

export async function mockAdminUserResetPassword(
  token: string,
  userId: number,
  newPassword: string
): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  if (!newPassword || newPassword.length < 6) {
    return { success: false, message: '密码至少6个字符' };
  }
  const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
  await db.users.update(userId, { passwordHash, updatedAt: Date.now() });
  return { success: true, message: '密码已重置' };
}

export async function mockAdminUserDelete(token: string, userId: number): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  if (userId === adminUser.id) {
    return { success: false, message: '不能删除自己的账号' };
  }
  await db.users.delete(userId);
  await db.permissions.where('userId').equals(userId).delete();
  await db.bookshelves.where('userId').equals(userId).delete();
  return { success: true, message: '账号已删除' };
}

export async function mockAdminGetPermissions(
  token: string,
  userId: number
): Promise<ApiResponse<UserPermissions>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const permissions = await getUserPermissions(userId);
  return { success: true, message: 'ok', data: permissions };
}

export async function mockAdminUpdatePermissions(
  token: string,
  userId: number,
  permissions: UserPermissions
): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const existing = await db.permissions.where('userId').equals(userId).first();
  if (existing) {
      await db.permissions.update(existing.id!, {
        canWriteShort: permissions.canWriteShort ? 1 : 0,
        canDisassemble: permissions.canDisassemble ? 1 : 0,
        canHotRank: permissions.canHotRank ? 1 : 0,
        canOptimize: permissions.canOptimize ? 1 : 0,
        canWorkbench: permissions.canWorkbench ? 1 : 0,
        canUploadContinue: permissions.canUploadContinue ? 1 : 0,
        configuredByAdmin: 1,
        updatedAt: Date.now(),
      });
    } else {
      await db.permissions.add({
        userId,
        canWriteShort: permissions.canWriteShort ? 1 : 0,
        canDisassemble: permissions.canDisassemble ? 1 : 0,
        canHotRank: permissions.canHotRank ? 1 : 0,
        canOptimize: permissions.canOptimize ? 1 : 0,
        canWorkbench: permissions.canWorkbench ? 1 : 0,
        canUploadContinue: permissions.canUploadContinue ? 1 : 0,
        configuredByAdmin: 1,
        updatedAt: Date.now(),
      });
    }
  return { success: true, message: '权限已更新' };
}

// ========== 等级权限配置 ==========

export interface LevelPermissionsMap {
  none: UserPermissions;
  plus: UserPermissions;
  ultra: UserPermissions;
}

export async function mockAdminGetLevelPermissions(
  token: string
): Promise<ApiResponse<LevelPermissionsMap>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const none = await getLevelPermissions('none');
  const plus = await getLevelPermissions('plus');
  const ultra = await getLevelPermissions('ultra');
  return { success: true, message: 'ok', data: { none, plus, ultra } };
}

function permObjToRow(permissions: UserPermissions): Omit<DBLevelPermission, 'id' | 'level' | 'updatedAt' | 'configuredByAdmin'> {
  return {
    canWriteShort: permissions.canWriteShort ? 1 : 0,
    canDisassemble: permissions.canDisassemble ? 1 : 0,
    canHotRank: permissions.canHotRank ? 1 : 0,
    canOptimize: permissions.canOptimize ? 1 : 0,
    canWorkbench: permissions.canWorkbench ? 1 : 0,
    canUploadContinue: permissions.canUploadContinue ? 1 : 0,
  };
}

export async function mockAdminUpdateLevelPermission(
  token: string,
  level: 'none' | 'plus' | 'ultra',
  permissions: UserPermissions
): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const existing = await db.levelPermissions.where('level').equals(level).first();
  const now = Date.now();
  if (existing) {
    await db.levelPermissions.update(existing.id!, {
      ...permObjToRow(permissions),
      configuredByAdmin: 1,
      updatedAt: now,
    });
  } else {
    await db.levelPermissions.add({
      level,
      ...permObjToRow(permissions),
      configuredByAdmin: 1,
      updatedAt: now,
    });
  }
  return { success: true, message: `${level === 'none' ? '普通用户' : level === 'plus' ? 'Plus 会员' : 'Ultra 会员'} 权限已更新` };
}

// ========== 作品接口 ==========

export async function mockGetAllBooks(token: string): Promise<ApiResponse<{ books: IBookWork[] }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const rows = await db.bookshelves
    .where('userId')
    .equals(user.id!)
    .reverse()
    .sortBy('updatedAt');
  const books = rows.map((row) => JSON.parse(row.data) as IBookWork);
  return { success: true, message: 'ok', data: { books } };
}

export async function mockGetBook(token: string, bookId: string): Promise<ApiResponse<{ book: IBookWork }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const row = await db.bookshelves.get(bookId);
  if (!row || row.userId !== user.id!) {
    return { success: false, message: '作品不存在' };
  }
  return { success: true, message: 'ok', data: { book: JSON.parse(row.data) as IBookWork } };
}

export async function mockCreateBook(token: string, book: IBookWork): Promise<ApiResponse<{ book: IBookWork }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }

  // Plus 会员作品数量限制：最多 2 部；Ultra 和管理员不受限
  const isAdmin = !!user.isAdmin;
  const level = user.membershipLevel || 'none';
  const isPlusActive = level === 'plus' && (!user.membershipExpireAt || user.membershipExpireAt > Date.now());
  const isUltraActive = level === 'ultra' && (!user.membershipExpireAt || user.membershipExpireAt > Date.now());
  if (!isAdmin && !isUltraActive && isPlusActive) {
    const currentCount = await db.bookshelves.where('userId').equals(user.id!).count();
    if (currentCount >= 2) {
      return {
        success: false,
        message: 'Plus 会员最多保存 2 部作品，升级 Ultra 可解锁不限数量',
      };
    }
  }

  const now = Date.now();
  const bookWithTime: IBookWork = {
    ...book,
    createdAt: now,
    updatedAt: now,
  };
  await db.bookshelves.add({
    bookId: book.id,
    userId: user.id!,
    data: JSON.stringify(bookWithTime),
    createdAt: now,
    updatedAt: now,
  });
  return { success: true, message: '创建成功', data: { book: bookWithTime } };
}

export async function mockSaveBook(token: string, book: IBookWork): Promise<ApiResponse<{ book: IBookWork }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const existing = await db.bookshelves.get(book.id);
  if (!existing) {
    // 不存在则创建
    return mockCreateBook(token, book);
  }
  if (existing.userId !== user.id!) {
    return { success: false, message: '无权限修改' };
  }
  const now = Date.now();
  const updatedBook: IBookWork = { ...book, updatedAt: now };
  const updatedCount = await db.bookshelves.update(book.id, {
    data: JSON.stringify(updatedBook),
    updatedAt: now,
  });
  if (updatedCount === 0) {
    logger.error('[mock-backend] saveBook update 未命中任何记录', { bookId: book.id });
    return { success: false, message: '保存失败：作品记录不存在' };
  }
  return { success: true, message: '保存成功', data: { book: updatedBook } };
}

export async function mockDeleteBook(token: string, bookId: string): Promise<ApiResponse> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const existing = await db.bookshelves.get(bookId);
  if (!existing || existing.userId !== user.id!) {
    return { success: false, message: '作品不存在' };
  }
  await db.bookshelves.delete(bookId);
  return { success: true, message: '删除成功' };
}

// ========== 每日字数统计 ==========

const PLUS_DAILY_WORD_LIMIT = 100000;

function getTodayKey(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

async function getTodayWordUsage(userId: number): Promise<number> {
  const row = await db.dailyWordUsage
    .where('[userId+dateKey]')
    .equals([userId, getTodayKey()])
    .first();
  return row?.wordCount || 0;
}

/**
 * 校验 Plus 会员每日字数限制，并累加生成字数。
 * Ultra / 管理员不受限；未登录游客也不限制。
 * 返回 { ok, used, limit, message }：ok=false 表示超限。
 */
export async function consumeDailyWordQuota(
  token: string,
  generatedChars: number
): Promise<{ ok: boolean; used: number; limit: number; message: string }> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  // 未登录 / 管理员 / Ultra 会员：不限制
  if (!user || user.isAdmin) {
    return { ok: true, used: 0, limit: Infinity, message: '' };
  }
  const level = user.membershipLevel || 'none';
  const expireAt = user.membershipExpireAt || 0;
  const isUltraActive = level === 'ultra' && (!expireAt || expireAt > Date.now());
  if (isUltraActive) {
    return { ok: true, used: 0, limit: Infinity, message: '' };
  }

  const userId = user.id!;
  const todayKey = getTodayKey();
  const now = Date.now();
  const used = await getTodayWordUsage(userId);
  const limit = PLUS_DAILY_WORD_LIMIT;

  if (used + generatedChars > limit) {
    return {
      ok: false,
      used,
      limit,
      message: `今日已生成 ${used} 字，Plus 会员每日最多 10 万字，升级 Ultra 可解锁无上限生成`,
    };
  }

  // 累加
  const existing = await db.dailyWordUsage
    .where('[userId+dateKey]')
    .equals([userId, todayKey])
    .first();
  if (existing) {
    await db.dailyWordUsage.update(existing.id!, {
      wordCount: existing.wordCount + generatedChars,
      updatedAt: now,
    });
  } else {
    await db.dailyWordUsage.add({
      userId,
      dateKey: todayKey,
      wordCount: generatedChars,
      updatedAt: now,
    });
  }

  return { ok: true, used: used + generatedChars, limit, message: '' };
}

// ========== 会员设置接口 ==========

export async function mockAdminSetMembership(
  token: string,
  userId: number,
  level: 'none' | 'plus' | 'ultra',
  days: number
): Promise<ApiResponse<{ membershipLevel: 'none' | 'plus' | 'ultra'; membershipExpireAt: number }>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const target = await db.users.get(userId);
  if (!target) {
    return { success: false, message: '用户不存在' };
  }
  const now = Date.now();
  let newLevel = level;
  let newExpireAt = 0;
  if (level === 'none') {
    newLevel = 'none';
    newExpireAt = 0;
  } else {
    newLevel = level;
    newExpireAt = now + days * 86400000;
  }
  await db.users.update(userId, {
    membershipLevel: newLevel,
    membershipExpireAt: newExpireAt,
    updatedAt: now,
  });
  return {
    success: true,
    message: '设置成功',
    data: { membershipLevel: newLevel, membershipExpireAt: newExpireAt },
  };
}

export async function mockAdminExtendMembership(
  token: string,
  userId: number,
  days: number
): Promise<ApiResponse<{ membershipLevel: 'none' | 'plus' | 'ultra'; membershipExpireAt: number }>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const target = await db.users.get(userId);
  if (!target) {
    return { success: false, message: '用户不存在' };
  }
  const now = Date.now();
  const currentLevel = target.membershipLevel || 'none';
  if (currentLevel === 'none') {
    return { success: false, message: '用户不是会员，请先设置会员等级' };
  }
  const currentExpire = target.membershipExpireAt || 0;
  const base = currentExpire > now ? currentExpire : now;
  const newExpireAt = base + days * 86400000;
  await db.users.update(userId, {
    membershipExpireAt: newExpireAt,
    updatedAt: now,
  });
  return {
    success: true,
    message: `已延长 ${days} 天`,
    data: { membershipLevel: currentLevel, membershipExpireAt: newExpireAt },
  };
}

// ========== 公告接口 ==========

export async function mockGetCurrentAnnouncement(): Promise<ApiResponse<{ id: number; title: string; content: string; isEnabled: boolean; updatedAt: number } | null>> {
  await getInitPromise();
  const rows = await db.announcements.orderBy('id').reverse().limit(1).toArray();
  if (rows.length === 0 || !rows[0].isEnabled) {
    return { success: true, message: 'ok', data: null };
  }
  const row = rows[0];
  return {
    success: true,
    message: 'ok',
    data: {
      id: row.id!,
      title: row.title,
      content: row.content,
      isEnabled: !!row.isEnabled,
      updatedAt: row.updatedAt,
    },
  };
}

export async function mockAdminGetAnnouncement(token: string): Promise<ApiResponse<{ id: number; title: string; content: string; isEnabled: boolean; updatedAt: number } | null>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const rows = await db.announcements.orderBy('id').reverse().limit(1).toArray();
  if (rows.length === 0) {
    return { success: true, message: 'ok', data: null };
  }
  const row = rows[0];
  return {
    success: true,
    message: 'ok',
    data: {
      id: row.id!,
      title: row.title,
      content: row.content,
      isEnabled: !!row.isEnabled,
      updatedAt: row.updatedAt,
    },
  };
}

export async function mockAdminSaveAnnouncement(
  token: string,
  data: { title: string; content: string; isEnabled: boolean }
): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const now = Date.now();
  const rows = await db.announcements.orderBy('id').reverse().limit(1).toArray();
  if (rows.length > 0) {
    await db.announcements.update(rows[0].id!, {
      title: data.title,
      content: data.content,
      isEnabled: data.isEnabled ? 1 : 0,
      updatedAt: now,
    });
  } else {
    await db.announcements.add({
      title: data.title,
      content: data.content,
      isEnabled: data.isEnabled ? 1 : 0,
      updatedAt: now,
    });
  }
  return { success: true, message: '公告已保存' };
}

// ========== 兑换码接口 ==========

export async function mockAdminRedemptionList(
  token: string,
  options?: { keyword?: string; status?: string }
): Promise<ApiResponse<Array<{ id: number; code: string; membershipLevel: 'plus' | 'ultra'; days: number; isActive: boolean; isUsed: boolean; usedBy?: number; usedAt?: number; createdAt: number; updatedAt: number }>>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  let all = await db.redemptionCodes.orderBy('id').reverse().limit(100).toArray();
  if (options?.keyword && options.keyword.trim()) {
    const kw = options.keyword.toUpperCase();
    all = all.filter((c) => c.code.includes(kw));
  }
  if (options?.status === 'active') {
    all = all.filter((c) => c.isActive && !c.isUsed);
  } else if (options?.status === 'used') {
    all = all.filter((c) => c.isUsed);
  } else if (options?.status === 'disabled') {
    all = all.filter((c) => !c.isActive);
  }
  const result = all.map((c) => ({
    id: c.id!,
    code: c.code,
    membershipLevel: c.membershipLevel,
    days: c.days,
    isActive: !!c.isActive,
    isUsed: !!c.isUsed,
    usedBy: c.usedBy,
    usedAt: c.usedAt,
    createdAt: c.createdAt,
    updatedAt: c.updatedAt,
  }));
  return { success: true, message: 'ok', data: result };
}

export async function mockAdminGenerateRedemptionCodes(
  token: string,
  data: { level: 'plus' | 'ultra'; days: number; count?: number; prefix?: string }
): Promise<ApiResponse<string[]>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  if (!data.level || !['plus', 'ultra'].includes(data.level)) {
    return { success: false, message: '会员等级无效' };
  }
  if (typeof data.days !== 'number' || data.days <= 0) {
    return { success: false, message: '天数无效' };
  }
  const count = typeof data.count === 'number' && data.count > 0 && data.count <= 100 ? data.count : 1;
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const p = (data.prefix || '').toUpperCase();
  const now = Date.now();
  const generated: string[] = [];

  for (let i = 0; i < count; i++) {
    let code = '';
    let attempts = 0;
    let unique = false;
    while (!unique && attempts < 10) {
      code = p;
      for (let j = 0; j < 12; j++) {
        code += chars[Math.floor(Math.random() * chars.length)];
      }
      const existing = await db.redemptionCodes.where('code').equals(code).first();
      if (!existing) unique = true;
      attempts++;
    }
    await db.redemptionCodes.add({
      code,
      membershipLevel: data.level,
      days: data.days,
      isActive: 1,
      isUsed: 0,
      createdAt: now,
      updatedAt: now,
    });
    generated.push(code);
  }
  return {
    success: true,
    message: `已生成 ${generated.length} 个兑换码`,
    data: generated,
  };
}

export async function mockAdminToggleRedemptionCode(
  token: string,
  codeId: number
): Promise<ApiResponse<{ isActive: boolean }>> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  const code = await db.redemptionCodes.get(codeId);
  if (!code) {
    return { success: false, message: '兑换码不存在' };
  }
  if (code.isUsed) {
    return { success: false, message: '已兑换的码无法停用' };
  }
  const newActive = code.isActive ? 0 : 1;
  await db.redemptionCodes.update(codeId, { isActive: newActive, updatedAt: Date.now() });
  return {
    success: true,
    message: newActive ? '已启用' : '已停用',
    data: { isActive: !!newActive },
  };
}

export async function mockAdminDeleteRedemptionCode(token: string, codeId: number): Promise<ApiResponse> {
  await getInitPromise();
  const adminUser = await getCurrentUserFromToken(token);
  if (!adminUser || !adminUser.isAdmin) {
    return { success: false, message: '无管理员权限' };
  }
  await db.redemptionCodes.delete(codeId);
  return { success: true, message: '已删除' };
}

export async function mockRedeemCode(
  token: string,
  code: string
): Promise<ApiResponse<{ membershipLevel: 'plus' | 'ultra'; membershipExpireAt: number }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const codeUpper = code.toUpperCase().trim();
  const codeRow = await db.redemptionCodes.where('code').equals(codeUpper).first();
  if (!codeRow) {
    return { success: false, message: '兑换码不存在' };
  }
  if (!codeRow.isActive) {
    return { success: false, message: '兑换码已停用' };
  }
  if (codeRow.isUsed) {
    return { success: false, message: '兑换码已被使用' };
  }
  const now = Date.now();
  const currentLevel = user.membershipLevel || 'none';
  const currentExpire = user.membershipExpireAt || 0;
  let newLevel: 'plus' | 'ultra';
  let newExpireAt: number;
  if (currentLevel === 'none' || currentExpire <= now) {
    newLevel = codeRow.membershipLevel;
    newExpireAt = now + codeRow.days * 86400000;
  } else {
    // 同等级叠加，高等级覆盖剩余
    if (codeRow.membershipLevel === 'ultra' || currentLevel === 'ultra') {
      newLevel = 'ultra';
    } else {
      newLevel = 'plus';
    }
    newExpireAt = currentExpire + codeRow.days * 86400000;
  }
  await db.users.update(user.id!, {
    membershipLevel: newLevel,
    membershipExpireAt: newExpireAt,
    updatedAt: now,
  });
  await db.redemptionCodes.update(codeRow.id!, {
    isUsed: 1,
    usedBy: user.id!,
    usedAt: now,
    updatedAt: now,
  });
  return {
    success: true,
    message: '兑换成功',
    data: { membershipLevel: newLevel, membershipExpireAt: newExpireAt },
  };
}

// ========== 数据导出/导入（跨设备迁移） ==========

export interface ExportData {
  version: 1;
  exportAt: number;
  account: string;
  user: Omit<DBUser, 'passwordHash'> & { id: number };
  permissions?: UserPermissions;
  books: IBookWork[];
}

export async function mockExportUserData(token: string): Promise<ApiResponse<ExportData>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录' };
  }
  const level = user.membershipLevel || 'none';
  const permissions = await getUserPermissions(user.id!, level);
  const bookRows = await db.bookshelves.where('userId').equals(user.id!).toArray();
  const books = bookRows.map((r) => JSON.parse(r.data) as IBookWork);
  const userData: Omit<DBUser, 'passwordHash'> & { id: number } = {
    id: user.id!,
    account: user.account,
    isAdmin: user.isAdmin as number,
    status: user.status,
    membershipLevel: user.membershipLevel || 'none',
    membershipExpireAt: user.membershipExpireAt || 0,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
  return {
    success: true,
    message: '导出成功',
    data: {
      version: 1,
      exportAt: Date.now(),
      account: user.account,
      user: userData,
      permissions,
      books,
    },
  };
}

export async function mockImportUserData(
  token: string,
  importData: ExportData
): Promise<ApiResponse<{ importedBooks: number; skippedBooks: number }>> {
  await getInitPromise();
  const user = await getCurrentUserFromToken(token);
  if (!user) {
    return { success: false, message: '未登录，请先登录目标账号' };
  }
  if (!importData || importData.version !== 1) {
    return { success: false, message: '数据格式无效' };
  }
  if (!Array.isArray(importData.books)) {
    return { success: false, message: '作品数据格式错误' };
  }
  let imported = 0;
  let skipped = 0;
  const now = Date.now();
  for (const book of importData.books) {
    if (!book || !book.id) {
      skipped++;
      continue;
    }
    const existing = await db.bookshelves.get(book.id);
    if (existing) {
      // 同 ID 且属于当前用户则跳过
      if (existing.userId === user.id!) {
        skipped++;
        continue;
      }
      // 属于其他人则生成新 ID
      const newId = `${book.id}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const newBook = { ...book, id: newId, updatedAt: now };
      await db.bookshelves.add({
        bookId: newId,
        userId: user.id!,
        data: JSON.stringify(newBook),
        createdAt: now,
        updatedAt: now,
      });
      imported++;
    } else {
      const newBook = { ...book, updatedAt: now };
      await db.bookshelves.add({
        bookId: book.id,
        userId: user.id!,
        data: JSON.stringify(newBook),
        createdAt: now,
        updatedAt: now,
      });
      imported++;
    }
  }
  return {
    success: true,
    message: `导入完成：成功 ${imported} 部，跳过 ${skipped} 部`,
    data: { importedBooks: imported, skippedBooks: skipped },
  };
}

// ========== 后端可用性检测 ==========

let backendAvailable: boolean | null = null;

/**
 * 检测真实后端是否可用
 */
export async function checkBackendAvailable(): Promise<boolean> {
  if (backendAvailable !== null) return backendAvailable;
  try {
    const res = await fetch('/api/health', { method: 'GET' });
    const contentType = res.headers.get('content-type') || '';
    // 必须返回 JSON 才算后端可用；Vite SPA fallback 会返回 HTML，200 但不是 JSON
    backendAvailable = res.ok && contentType.includes('application/json');
    logger.info('[mock-backend] 真实后端可用性:', backendAvailable ? '可用' : '不可用（启用本地 IndexedDB）');
  } catch {
    backendAvailable = false;
    logger.info('[mock-backend] 真实后端不可用，启用本地 IndexedDB 模式');
  }
  return backendAvailable;
}

/**
 * 重置检测状态（开发环境热重载时用）
 */
export function resetBackendCheck(): void {
  backendAvailable = null;
}
