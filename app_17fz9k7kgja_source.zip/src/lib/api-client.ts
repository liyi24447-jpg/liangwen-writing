import { scopedStorage, logger } from '@lark-apaas/client-toolkit-lite';
import {
  checkBackendAvailable,
  resetBackendCheck,
  mockLogin,
  mockRegister,
  mockMe,
  mockChangePassword,
  mockAdminStats,
  mockAdminUserList,
  mockAdminUserDisable,
  mockAdminUserResetPassword,
  mockAdminUserDelete,
  mockAdminGetPermissions,
  mockAdminUpdatePermissions,
  mockAdminGetLevelPermissions,
  mockAdminUpdateLevelPermission,
  mockAdminSetMembership,
  mockAdminExtendMembership,
  mockGetCurrentAnnouncement,
  mockAdminGetAnnouncement,
  mockAdminSaveAnnouncement,
  mockAdminRedemptionList,
  mockAdminGenerateRedemptionCodes,
  mockAdminToggleRedemptionCode,
  mockAdminDeleteRedemptionCode,
  mockRedeemCode,
  mockExportUserData,
  mockImportUserData,
  mockGetAllBooks,
  mockGetBook,
  mockCreateBook,
  mockSaveBook,
  mockDeleteBook,
} from '@/lib/mock-backend';
import type { ExportData } from '@/lib/mock-backend';
import type { IBookWork } from '@/data/novel';

const TOKEN_KEY = 'liangwen_auth_token';

/**
 * 获取存储的 JWT token
 */
export function getAuthToken(): string | null {
  return scopedStorage.getItem(TOKEN_KEY);
}

/**
 * 保存 token
 */
export function setAuthToken(token: string): void {
  scopedStorage.setItem(TOKEN_KEY, token);
}

/**
 * 清除 token
 */
export function clearAuthToken(): void {
  scopedStorage.removeItem(TOKEN_KEY);
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
}

/**
 * 统一的 API 请求封装
 * - 真实后端可用时走 fetch
 * - 后端不可用时自动降级到 IndexedDB 模拟后端
 */
export async function apiRequest<T = unknown>(
  path: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const token = getAuthToken();

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const backendOk = await checkBackendAvailable();

  if (backendOk) {
    // 真实后端
    try {
      const res = await fetch(`/api${path}`, {
        ...options,
        headers,
      });

      // 检查响应是否为 JSON
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        // 返回的不是 JSON，说明后端可能挂了或代理失效，降级到 mock
        logger.warn('[api] 响应非 JSON，降级到本地 IndexedDB 模式');
        resetBackendCheck();
        return mockRequest<T>(path, options, token);
      }

      const data = (await res.json()) as ApiResponse<T>;

      if (!res.ok) {
        if (res.status === 401) {
          clearAuthToken();
          window.location.reload();
        }
        logger.warn(`[api] ${path} 失败: ${res.status} - ${data.message || ''}`);
        return {
          success: false,
          message: data.message || `请求失败 (${res.status})`,
        };
      }

      return data;
    } catch (error) {
      logger.error(`[api] ${path} 网络错误: ${String(error)}`);
      // 网络错误也降级到 mock
      resetBackendCheck();
      return mockRequest<T>(path, options, token);
    }
  } else {
    // 后端不可用，走本地 IndexedDB
    return mockRequest<T>(path, options, token);
  }
}

/**
 * 分发到对应的 mock 函数
 * 契约与 Express 后端保持一致
 */
async function mockRequest<T>(
  path: string,
  options: RequestInit,
  token: string | null
): Promise<ApiResponse<T>> {
  try {
    const method = (options.method || 'GET').toUpperCase();
    const body = options.body ? (JSON.parse(options.body as string) as Record<string, unknown>) : {};
    const [pathname] = path.split('?');
    const query = new URLSearchParams(path.split('?')[1] || '');

  // ===== 认证相关 =====
  if (pathname === '/auth/login' && method === 'POST') {
    return mockLogin(body.account as string, body.password as string) as Promise<ApiResponse<T>>;
  }
  if (pathname === '/auth/register' && method === 'POST') {
    return mockRegister(body.account as string, body.password as string) as Promise<ApiResponse<T>>;
  }
  if (pathname === '/auth/me' && method === 'GET') {
    return mockMe(token || '') as Promise<ApiResponse<T>>;
  }
  if (pathname === '/auth/change-password' && method === 'POST') {
    return mockChangePassword(
      token || '',
      body.oldPassword as string,
      body.newPassword as string
    ) as Promise<ApiResponse<T>>;
  }

  // ===== 管理后台 =====
  if (pathname === '/admin/stats' && method === 'GET') {
    return mockAdminStats(token || '') as Promise<ApiResponse<T>>;
  }
  if (pathname === '/admin/users' && method === 'GET') {
    // 返回格式与后端一致：直接数组（包裹在 ApiResponse.data 中）
    const res = await mockAdminUserList(token || '', query.get('keyword') || undefined);
    if (res.success && res.data) {
      // 将 { users: [...] } 展平为 [...]，与真实后端一致
      return { ...res, data: res.data.users as unknown as T };
    }
    return res as unknown as ApiResponse<T>;
  }
  // POST /admin/users/:id/toggle-status
  const toggleMatch = pathname.match(/^\/admin\/users\/(\d+)\/toggle-status$/);
  if (toggleMatch && method === 'POST') {
    const userId = Number(toggleMatch[1]);
    // 调用 disable，通过查询当前状态来 toggle
    const listRes = await mockAdminUserList(token || '');
    if (!listRes.success || !listRes.data) {
      return { success: false, message: '操作失败' } as ApiResponse<T>;
    }
    const target = listRes.data.users.find((u) => u.id === userId);
    if (!target) {
      return { success: false, message: '用户不存在' } as ApiResponse<T>;
    }
    const disabled = target.isActive; // 当前 active → 要禁用
    const res = await mockAdminUserDisable(token || '', userId, disabled);
    if (res.success) {
      return { ...res, data: { isActive: !disabled } as unknown as T };
    }
    return res as unknown as ApiResponse<T>;
  }
  // POST /admin/users/:id/reset-password
  const resetMatch = pathname.match(/^\/admin\/users\/(\d+)\/reset-password$/);
  if (resetMatch && method === 'POST') {
    return mockAdminUserResetPassword(
      token || '',
      Number(resetMatch[1]),
      body.newPassword as string
    ) as Promise<ApiResponse<T>>;
  }
  // POST /admin/users/:id/permissions (body 直接是 permissions 对象)
  // PATCH /admin/users/:id/permissions (body: { permissions: {...} })
  const permMatch = pathname.match(/^\/admin\/users\/(\d+)\/permissions$/);
  if (permMatch && (method === 'POST' || method === 'PATCH')) {
    const perms = (method === 'PATCH' ? (body.permissions as UserPermissions) : body) as UserPermissions;
    return mockAdminUpdatePermissions(
      token || '',
      Number(permMatch[1]),
      perms
    ) as Promise<ApiResponse<T>>;
  }
  // GET /admin/users/:id/permissions
  if (permMatch && method === 'GET') {
    return mockAdminGetPermissions(
      token || '',
      Number(permMatch[1])
    ) as Promise<ApiResponse<T>>;
  }
  // GET /admin/permissions/levels
  if (pathname === '/admin/permissions/levels' && method === 'GET') {
    return mockAdminGetLevelPermissions(token || '') as Promise<ApiResponse<T>>;
  }
  // PATCH /admin/permissions/levels/:level
  const levelPermMatch = pathname.match(/^\/admin\/permissions\/levels\/(none|plus|ultra)$/);
  if (levelPermMatch && method === 'PATCH') {
    const perms = ((body.permissions as unknown as UserPermissions) || (body as unknown as UserPermissions));
    return mockAdminUpdateLevelPermission(
      token || '',
      levelPermMatch[1] as 'none' | 'plus' | 'ultra',
      perms
    ) as Promise<ApiResponse<T>>;
  }
  // DELETE /admin/users/:id
  const deleteMatch = pathname.match(/^\/admin\/users\/(\d+)$/);
  if (deleteMatch && method === 'DELETE') {
    return mockAdminUserDelete(token || '', Number(deleteMatch[1])) as Promise<ApiResponse<T>>;
  }

  // ===== 作品相关 =====
  if (pathname === '/books' && method === 'GET') {
    const res = await mockGetAllBooks(token || '');
    // 与真实后端一致：直接返回数组
    if (res.success && res.data) {
      return { ...res, data: res.data.books as unknown as T };
    }
    return res as unknown as ApiResponse<T>;
  }
  if (pathname === '/books' && method === 'POST') {
    // body 直接是 book 对象（与真实后端一致）
    const res = await mockCreateBook(token || '', body as unknown as IBookWork);
    if (res.success && res.data) {
      return { ...res, data: res.data.book as unknown as T };
    }
    return res as unknown as ApiResponse<T>;
  }
  // GET /books/:id
  const bookGetMatch = pathname.match(/^\/books\/([^/]+)$/);
  if (bookGetMatch && method === 'GET') {
    const res = await mockGetBook(token || '', bookGetMatch[1]);
    if (res.success && res.data) {
      return { ...res, data: res.data.book as unknown as T };
    }
    return res as unknown as ApiResponse<T>;
  }
  // PUT /books/:id
  const bookPutMatch = pathname.match(/^\/books\/([^/]+)$/);
  if (bookPutMatch && method === 'PUT') {
    const bookId = bookPutMatch[1];
    const book = { ...(body as unknown as IBookWork), id: bookId };
    const res = await mockSaveBook(token || '', book);
    if (res.success && res.data) {
      return { ...res, data: res.data.book as unknown as T };
    }
    return res as unknown as ApiResponse<T>;
  }
  // DELETE /books/:id
  const bookDelMatch = pathname.match(/^\/books\/([^/]+)$/);
  if (bookDelMatch && method === 'DELETE') {
    return mockDeleteBook(token || '', bookDelMatch[1]) as Promise<ApiResponse<T>>;
  }

  // ===== 公告 =====
  if (pathname === '/announcement/current' && method === 'GET') {
    return mockGetCurrentAnnouncement() as unknown as Promise<ApiResponse<T>>;
  }

  // ===== 兑换码兑换 =====
  if (pathname === '/redemption/redeem' && method === 'POST') {
    return mockRedeemCode(token || '', body.code as string) as unknown as Promise<ApiResponse<T>>;
  }

  // ===== 管理后台：公告 =====
  if (pathname === '/admin/announcement' && method === 'GET') {
    return mockAdminGetAnnouncement(token || '') as unknown as Promise<ApiResponse<T>>;
  }
  if (pathname === '/admin/announcement' && method === 'POST') {
    return mockAdminSaveAnnouncement(token || '', {
      title: body.title as string,
      content: body.content as string,
      isEnabled: body.isEnabled as boolean,
    }) as unknown as Promise<ApiResponse<T>>;
  }

  // ===== 管理后台：兑换码 =====
  if (pathname === '/admin/redemption-codes' && method === 'GET') {
    return mockAdminRedemptionList(token || '', {
      keyword: query.get('keyword') || undefined,
      status: query.get('status') || undefined,
    }) as unknown as Promise<ApiResponse<T>>;
  }
  if (pathname === '/admin/redemption-codes' && method === 'POST') {
    return mockAdminGenerateRedemptionCodes(token || '', {
      level: body.level as 'plus' | 'ultra',
      days: body.days as number,
      count: body.count as number | undefined,
      prefix: body.prefix as string | undefined,
    }) as unknown as Promise<ApiResponse<T>>;
  }
  const redeemToggleMatch = pathname.match(/^\/admin\/redemption-codes\/(\d+)\/toggle$/);
  if (redeemToggleMatch && method === 'POST') {
    return mockAdminToggleRedemptionCode(
      token || '',
      Number(redeemToggleMatch[1])
    ) as unknown as Promise<ApiResponse<T>>;
  }
  const redeemDelMatch = pathname.match(/^\/admin\/redemption-codes\/(\d+)$/);
  if (redeemDelMatch && method === 'DELETE') {
    return mockAdminDeleteRedemptionCode(
      token || '',
      Number(redeemDelMatch[1])
    ) as unknown as Promise<ApiResponse<T>>;
  }

  // ===== 管理后台：会员设置 =====
  const memberSetMatch = pathname.match(/^\/admin\/users\/(\d+)\/membership$/);
  if (memberSetMatch && method === 'POST') {
    return mockAdminSetMembership(
      token || '',
      Number(memberSetMatch[1]),
      body.level as 'none' | 'plus' | 'ultra',
      (body.days as number) || 0
    ) as unknown as Promise<ApiResponse<T>>;
  }
  const memberExtendMatch = pathname.match(/^\/admin\/users\/(\d+)\/membership\/extend$/);
  if (memberExtendMatch && method === 'POST') {
    return mockAdminExtendMembership(
      token || '',
      Number(memberExtendMatch[1]),
      (body.days as number) || 0
    ) as unknown as Promise<ApiResponse<T>>;
  }

  // ===== 数据导出/导入 =====
  if (pathname === '/data/export' && method === 'GET') {
    return mockExportUserData(token || '') as unknown as Promise<ApiResponse<T>>;
  }
  if (pathname === '/data/import' && method === 'POST') {
    return mockImportUserData(token || '', body as unknown as ExportData) as unknown as Promise<ApiResponse<T>>;
  }

  logger.warn('[mock-backend] 未匹配的 API 路径:', method, path);
  return { success: false, message: '接口暂不可用' };
  } catch (error) {
    logger.error(`[mock-backend] ${path} 处理异常: ${String(error)}`);
    return {
      success: false,
      message: error instanceof Error ? error.message : '数据加载异常，请刷新页面重试',
    };
  }
}

// ========== 认证 API ==========
export type MembershipLevel = 'none' | 'plus' | 'ultra';

export interface UserInfo {
  id: number;
  account: string;
  isAdmin: boolean;
  membershipLevel: MembershipLevel;
  membershipExpireAt: number;
}

export interface UserPermissions {
  canWriteShort: boolean;
  canDisassemble: boolean;
  canHotRank: boolean;
  canOptimize: boolean;
  canWorkbench: boolean;
  canUploadContinue: boolean;
}

export interface Announcement {
  id: number;
  title: string;
  content: string;
  isEnabled: boolean;
  updatedAt: number;
}

export interface RedemptionCode {
  id: number;
  code: string;
  membershipLevel: MembershipLevel;
  days: number;
  isActive: boolean;
  isUsed: boolean;
  usedBy?: number;
  usedAt?: number;
  createdAt: number;
  updatedAt: number;
}

export interface LoginResult {
  token: string;
  user: UserInfo;
}

export async function apiLogin(account: string, password: string): Promise<ApiResponse<LoginResult>> {
  return apiRequest<LoginResult>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ account, password }),
  });
}

export async function apiRegister(account: string, password: string): Promise<ApiResponse<LoginResult>> {
  return apiRequest<LoginResult>('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ account, password }),
  });
}

export async function apiMe(): Promise<ApiResponse<{ user: UserInfo; permissions: UserPermissions }>> {
  return apiRequest<{ user: UserInfo; permissions: UserPermissions }>('/auth/me', {
    method: 'GET',
  });
}

export async function apiChangePassword(oldPassword: string, newPassword: string): Promise<ApiResponse> {
  return apiRequest('/auth/change-password', {
    method: 'POST',
    body: JSON.stringify({ oldPassword, newPassword }),
  });
}

// ========== 管理后台 API ==========

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  adminUsers: number;
  totalBooks: number;
}

export interface AdminUserItem {
  id: number;
  account: string;
  isAdmin: boolean;
  isActive: boolean;
  createdAt: number;
  updatedAt: number;
  membershipLevel: MembershipLevel;
  membershipExpireAt: number;
  permissions: UserPermissions;
}

export async function apiAdminStats(): Promise<ApiResponse<AdminStats>> {
  return apiRequest<AdminStats>('/admin/stats', { method: 'GET' });
}

export async function apiAdminUserList(keyword?: string): Promise<ApiResponse<AdminUserItem[]>> {
  const qs = keyword ? `?keyword=${encodeURIComponent(keyword)}` : '';
  return apiRequest<AdminUserItem[]>(`/admin/users${qs}`, { method: 'GET' });
}

export async function apiAdminUserDisable(userId: number, disabled: boolean): Promise<ApiResponse> {
  return apiRequest(`/admin/users/${userId}/toggle-status`, {
    method: 'POST',
    body: JSON.stringify({ disabled }),
  });
}

export async function apiAdminUserResetPassword(userId: number, newPassword: string): Promise<ApiResponse> {
  return apiRequest(`/admin/users/${userId}/reset-password`, {
    method: 'PATCH',
    body: JSON.stringify({ newPassword }),
  });
}

export async function apiAdminUserDelete(userId: number): Promise<ApiResponse> {
  return apiRequest(`/admin/users/${userId}`, { method: 'DELETE' });
}

export async function apiAdminGetUserPermissions(userId: number): Promise<ApiResponse<UserPermissions>> {
  return apiRequest<UserPermissions>(`/admin/users/${userId}/permissions`, { method: 'GET' });
}

export async function apiAdminUpdateUserPermissions(
  userId: number,
  permissions: UserPermissions
): Promise<ApiResponse> {
  return apiRequest(`/admin/users/${userId}/permissions`, {
    method: 'PATCH',
    body: JSON.stringify({ permissions }),
  });
}

export interface LevelPermissionsMap {
  none: UserPermissions;
  plus: UserPermissions;
  ultra: UserPermissions;
}

export async function apiAdminGetLevelPermissions(): Promise<ApiResponse<LevelPermissionsMap>> {
  return apiRequest<LevelPermissionsMap>('/admin/permissions/levels', { method: 'GET' });
}

export async function apiAdminUpdateLevelPermission(
  level: 'none' | 'plus' | 'ultra',
  permissions: UserPermissions
): Promise<ApiResponse> {
  return apiRequest(`/admin/permissions/levels/${level}`, {
    method: 'PATCH',
    body: JSON.stringify({ permissions }),
  });
}

export async function apiAdminSetUserMembership(
  userId: number,
  level: MembershipLevel,
  days = 30
): Promise<ApiResponse<{ membershipLevel: MembershipLevel; membershipExpireAt: number }>> {
  return apiRequest(`/admin/users/${userId}/membership`, {
    method: 'POST',
    body: JSON.stringify({ level, days }),
  });
}

export async function apiAdminExtendMembership(
  userId: number,
  days: number
): Promise<ApiResponse<{ membershipLevel: MembershipLevel; membershipExpireAt: number }>> {
  return apiRequest(`/admin/users/${userId}/membership/extend`, {
    method: 'POST',
    body: JSON.stringify({ days }),
  });
}

export async function apiAdminGetAnnouncement(): Promise<ApiResponse<Announcement | null>> {
  return apiRequest<Announcement | null>('/admin/announcement', { method: 'GET' });
}

export async function apiAdminSaveAnnouncement(data: {
  title: string;
  content: string;
  isEnabled: boolean;
}): Promise<ApiResponse> {
  return apiRequest('/admin/announcement', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function apiAdminRedemptionCodeList(params?: {
  keyword?: string;
  status?: string;
}): Promise<ApiResponse<RedemptionCode[]>> {
  const qs = params ? `?${new URLSearchParams(params as Record<string, string>).toString()}` : '';
  return apiRequest<RedemptionCode[]>(`/admin/redemption-codes${qs}`, { method: 'GET' });
}

export async function apiAdminGenerateRedemptionCodes(data: {
  level: MembershipLevel;
  days: number;
  count?: number;
  prefix?: string;
}): Promise<ApiResponse<string[]>> {
  return apiRequest<string[]>('/admin/redemption-codes', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function apiAdminToggleRedemptionCode(codeId: number): Promise<ApiResponse<{ isActive: boolean }>> {
  return apiRequest<{ isActive: boolean }>(`/admin/redemption-codes/${codeId}/toggle`, {
    method: 'POST',
  });
}

export async function apiAdminDeleteRedemptionCode(codeId: number): Promise<ApiResponse> {
  return apiRequest(`/admin/redemption-codes/${codeId}`, { method: 'DELETE' });
}

// ========== 公告 API ==========

export async function apiGetCurrentAnnouncement(): Promise<ApiResponse<Announcement | null>> {
  return apiRequest<Announcement | null>('/announcement/current', { method: 'GET' });
}

// ========== 兑换码 API ==========

export async function apiRedeemCode(
  code: string
): Promise<ApiResponse<{ membershipLevel: MembershipLevel; membershipExpireAt: number }>> {
  return apiRequest<{ membershipLevel: MembershipLevel; membershipExpireAt: number }>('/redemption/redeem', {
    method: 'POST',
    body: JSON.stringify({ code }),
  });
}

// ========== 作品 API ==========

export async function apiGetAllBooks(): Promise<ApiResponse<{ books: IBookWork[] }>> {
  return apiRequest<{ books: IBookWork[] }>('/books', { method: 'GET' });
}

export async function apiGetBook(bookId: string): Promise<ApiResponse<{ book: IBookWork }>> {
  return apiRequest<{ book: IBookWork }>(`/books/${bookId}`, { method: 'GET' });
}

export async function apiCreateBook(book: IBookWork): Promise<ApiResponse<{ book: IBookWork }>> {
  return apiRequest<{ book: IBookWork }>('/books', {
    method: 'POST',
    body: JSON.stringify({ book }),
  });
}

export async function apiSaveBook(book: IBookWork): Promise<ApiResponse<{ book: IBookWork }>> {
  return apiRequest<{ book: IBookWork }>(`/books/${book.id}`, {
    method: 'PUT',
    body: JSON.stringify(book),
  });
}

export async function apiDeleteBook(bookId: string): Promise<ApiResponse> {
  return apiRequest(`/books/${bookId}`, { method: 'DELETE' });
}

// ========== 数据导出/导入 API（跨设备迁移） ==========

export interface ExportResult {
  version: 1;
  exportAt: number;
  account: string;
  user: {
    id: number;
    account: string;
    isAdmin: boolean;
    status: string;
    membershipLevel: MembershipLevel;
    membershipExpireAt: number;
    createdAt: number;
    updatedAt: number;
  };
  permissions: UserPermissions;
  books: IBookWork[];
}

export async function apiExportUserData(): Promise<ApiResponse<ExportResult>> {
  return apiRequest<ExportResult>('/data/export', { method: 'GET' });
}

export async function apiImportUserData(data: ExportResult): Promise<ApiResponse<{ importedBooks: number; skippedBooks: number }>> {
  return apiRequest('/data/import', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}
