import { scopedStorage, logger } from '@lark-apaas/client-toolkit-lite';
import type { IBookWork } from '@/data/novel';
import {
  getCurrentAccount,
  getCurrentSession as getSessionFromStorage,
  setSession as setSessionInStorage,
  clearSession as clearSessionInStorage,
  getBooksStorageKey,
  type AuthSession,
} from '@/lib/storage-keys';

// ========== 存储层说明 ==========
// 账号与作品数据当前基于 scopedStorage 本地持久化实现（真实存储，非内存 mock，刷新不丢失）
// 账号密码均使用 SHA-256 哈希存储，不明文保存密码
// 作品数据按账号隔离：每个账号的作品存在独立 key 下

const USERS_STORAGE_KEY = 'liangwen_users';

// ========== SHA-256 哈希 ==========
async function sha256(message: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// ========== 会话管理 ==========
export function getCurrentSession(): AuthSession | null {
  return getSessionFromStorage();
}

export type { AuthSession };

export function setSession(session: AuthSession): void {
  setSessionInStorage(session);
}

export function clearSession(): void {
  clearSessionInStorage();
}

export { getCurrentAccount };

// ========== 用户账号存储 ==========
interface UserRecord {
  account: string;
  passwordHash: string;
  createdAt: number;
}

function getAllUsers(): UserRecord[] {
  try {
    const raw = scopedStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as UserRecord[];
  } catch {
    return [];
  }
}

function saveUsers(users: UserRecord[]): void {
  scopedStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}

// ========== 注册 ==========
export interface RegisterResult {
  success: boolean;
  message: string;
}

export async function register(account: string, password: string): Promise<RegisterResult> {
  const trimmedAccount = account.trim();
  if (!trimmedAccount) return { success: false, message: '账号不能为空' };
  if (!password) return { success: false, message: '密码不能为空' };
  if (trimmedAccount.length < 3) return { success: false, message: '账号长度至少 3 位' };
  if (password.length < 6) return { success: false, message: '密码长度至少 6 位' };

  const users = getAllUsers();
  if (users.some((u) => u.account === trimmedAccount)) {
    return { success: false, message: '该账号已存在，请直接登录或更换账号' };
  }

  const passwordHash = await sha256(password);
  users.push({
    account: trimmedAccount,
    passwordHash,
    createdAt: Date.now(),
  });
  saveUsers(users);

  logger.info(`[auth] 注册成功: ${trimmedAccount}`);
  return { success: true, message: '注册成功' };
}

// ========== 登录 ==========
export interface LoginResult {
  success: boolean;
  message: string;
  account?: string;
}

export async function login(account: string, password: string): Promise<LoginResult> {
  const trimmedAccount = account.trim();
  if (!trimmedAccount) return { success: false, message: '请输入账号' };
  if (!password) return { success: false, message: '请输入密码' };

  const users = getAllUsers();
  const user = users.find((u) => u.account === trimmedAccount);

  if (!user) {
    return { success: false, message: '账号不存在，请先注册' };
  }

  const passwordHash = await sha256(password);
  if (user.passwordHash !== passwordHash) {
    return { success: false, message: '密码错误，请重试' };
  }

  setSessionInStorage({ account: trimmedAccount, loginAt: Date.now() });
  logger.info(`[auth] 登录成功: ${trimmedAccount}`);
  return { success: true, message: '登录成功', account: trimmedAccount };
}

// ========== 登出 ==========
export function logout(): void {
  const session = getSessionFromStorage();
  clearSessionInStorage();
  if (session) {
    logger.info(`[auth] 退出登录: ${session.account}`);
  }
}

// ========== 作品数据按账号隔离（与 novel-generator 共用同一 key 计算逻辑） ==========
export function getAllBooksForCurrentUser(): IBookWork[] {
  try {
    const raw = scopedStorage.getItem(getBooksStorageKey());
    if (!raw) return [];
    return JSON.parse(raw) as IBookWork[];
  } catch {
    return [];
  }
}

export function getBookForCurrentUser(id: string): IBookWork | undefined {
  return getAllBooksForCurrentUser().find((b) => b.id === id);
}
